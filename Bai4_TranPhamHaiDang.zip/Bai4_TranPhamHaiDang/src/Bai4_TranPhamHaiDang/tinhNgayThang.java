package Bai4_TranPhamHaiDang;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class tinhNgayThang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap ngay:");
		int ngay = sc.nextInt();
		System.out.println("Nhap thang:");
		int thang = sc.nextInt();
		System.out.println("Nhap nam:");
		int nam = sc.nextInt();
		switch (thang) {
		case 2:
			ktNgayThang(ngay, thang, nam, 29);
			break;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			ktNgayThang(ngay, thang, nam, 31);
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			ktNgayThang(ngay, thang, nam, 30);
			break;
		default:
			System.out.println("Ngay va Thang khong hop le!");
			break;
		}
	}
	public static void ktNgayThang(int ngay, int thang, int nam, int soNgayTrongThang) {
		// TODO Auto-generated method stub
		if(thang == 2)
		{
			if(((nam % 4 == 0) && !(nam % 100 ==0)) || (nam % 400 ==0)) 
				soNgayTrongThang = 29;
			else soNgayTrongThang = 28;
		}
		if(ngay >= 1 && ngay <= soNgayTrongThang)
		{
			System.out.println("Ngay hop le!");
			System.out.println("Thang hop le!");
			System.out.println("Thang " + thang + " co " + soNgayTrongThang + " ngay");
			if(ngay < soNgayTrongThang) 
			{
				int ngayhomsau = ngay + 1;
				System.out.println("Ngay hom sau cua ngay da nhap la ngay: " + ngayhomsau + " thang " + thang + " nam " + nam);
			}
			else
			{
				if(thang < 12)
				{
					int thangsau = thang + 1;
					System.out.println("Ngay hom sau cua ngay da nhap la ngay: " + 1 + " thang " + thangsau + " nam " + nam);
				}
				else
				{
					int namsau = nam + 1;
					System.out.println("Ngay hom sau cua ngay da nhap la ngay: " + 1 + " thang " + 1 + " nam " + namsau);
				}
			}
			if(ngay != 1) 
			{
				int ngayhomtruoc = ngay - 1;
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay: " + ngayhomtruoc + " thang " + thang + " nam " + nam);
			}
			else
			{
				if(thang != 1)
				{
					int thangtruoc = thang - 1;
					switch (thangtruoc) {
					case 2:
						if(((nam % 4 == 0) && !(nam % 100 ==0)) || (nam % 400 ==0)) 
							soNgayTrongThang = 29;
						else soNgayTrongThang = 28;
						System.out.println("Ngay hom truoc cua ngay da nhap la ngay: " + soNgayTrongThang + " thang " + thangtruoc + " nam " + nam);
						break;
					case 1:
					case 3:
					case 5:
					case 7:
					case 8:
					case 10:
					case 12:
						System.out.println("Ngay hom truoc cua ngay da nhap la ngay: " + 31 + " thang " + thangtruoc + " nam " + nam);
					case 4:
					case 6:
					case 9:
					case 11:
						System.out.println("Ngay hom truoc cua ngay da nhap la ngay: " + 30 + " thang " + thangtruoc + " nam " + nam);
					default:
						break;
					}
				}
				else
				{
					int namsau = nam - 1;
					System.out.println("Ngay hom truoc cua ngay da nhap la ngay: " + 31 + " thang " + 1 + " nam " + namsau);
				}
			}
		}
		else 
		{
			System.out.println("Ngay khong hop le!");
			System.out.println("Thang hop le!");
			System.out.println("Thang " + thang + " co " + soNgayTrongThang + " ngay");
		}
	}
}
