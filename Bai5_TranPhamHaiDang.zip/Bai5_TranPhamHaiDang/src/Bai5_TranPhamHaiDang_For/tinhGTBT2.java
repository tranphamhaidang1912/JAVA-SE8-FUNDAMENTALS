package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class tinhGTBT2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int tong = 0;
		for(int i = 1; i <= n; i++)
		{
			if(ktSoNT(i)) 
				tong += i;
		}
		System.out.println("Tong cac so nguyen to nho hon hay bang n = " + tong);
		
	}
	public static boolean ktSoNT(int n) {
		// TODO Auto-generated method stub

		int dem = 0;
		for(int i = 1; i <= n; i++)
		{
			if(n % i == 0)
			{
				++dem;
				if(dem > 2) break;
			}
		}
		if(dem == 2) return true;
		else return false;
	}

}
