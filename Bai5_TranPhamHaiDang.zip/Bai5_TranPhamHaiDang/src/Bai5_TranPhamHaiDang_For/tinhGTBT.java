package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class tinhGTBT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int A = 0;
		int B = 0;
		int C = 1;
		int D = 1;
		for(int i = 1; i <= n; i++)
		{
			if(i % 2 != 0)
				A += i;
			else B += i;
			C *= i;
			if(i % 3 == 0)
				D *= i;
		}
		System.out.println("Ket qua A = " + A);
		System.out.println("Ket qua B = " + B);
		System.out.println("Ket qua C = " + C);
		System.out.println("Ket qua D = " + D);
	}

}
