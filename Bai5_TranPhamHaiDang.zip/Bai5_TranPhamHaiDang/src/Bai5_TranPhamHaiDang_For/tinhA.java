package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class tinhA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		System.out.println("Nhap x:");
		double x = sc.nextDouble();
		double s1 = (x * x + x + 1);
		double s2 = (x * x - x + 1);
		double S1 = 1;
		double S2 = 1;
		if(n != 0)
		{
			for(int i = 1; i <= n; i++)
			{
				S1 = S1 * s1;
				S2 = S2 * s2;
			}
		}
		double A = S1 + S2;
		System.out.println("A = (x * x + x + 1) mu n + (x * x - x + 1) mu n = " + A);
	}

}
