package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class inBangCuuChuong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Tu so:");
		int tuSo = sc.nextInt();
		System.out.println("Den so:");
		int denSo = sc.nextInt();
		for(int i = 1; i <= 9; i++)
		{
			for(int j = tuSo; j <= denSo; j++)
			{
				System.out.print(j + " x " + i + " = " + j * i + "\t");
			}
			System.out.println("\n");
		}
	}

}
