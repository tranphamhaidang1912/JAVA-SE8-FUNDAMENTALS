package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class tinhGiaiThua {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int giaiThua1 = 1;
		int giaiThua2 = 1;
		System.out.print(n + "! = 1");
		for(int i = 2; i <= n; i++)
		{
			giaiThua1 *= i;	
			System.out.print(" x " + i);
		}
		System.out.println(" = " + giaiThua1);
		if(n % 2 == 0)
		{
			giaiThua2 = 2;
			System.out.print(n + "!! = 2");
			for(int i = 4; i <= n; i++)
			{
				if(i % 2 == 0)
				{
					giaiThua2 *= i;
					System.out.print(" x " + i);
				}
			}
			System.out.println(" = " + giaiThua2);
		}
		else
		{
			System.out.print(n + "!! = 1");
			for(int i = 3; i <= n; i++)
			{
				if(i % 2 != 0)
				{
					giaiThua2 *= i;
					System.out.print(" x " + i);
				}
			}
			System.out.println(" = " + giaiThua2);
		}
	}

}
