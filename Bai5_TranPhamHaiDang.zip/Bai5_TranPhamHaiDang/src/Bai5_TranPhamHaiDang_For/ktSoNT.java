package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class ktSoNT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int dem = 0;
		for(int i = 1; i <= n; i++)
		{
			if(n % i == 0)
			{
				++dem;
				if(dem > 2) break;
			}
		}
		if(dem == 2) 
			System.out.println(n + " La so NT");
		else
			System.out.println(n + " Khong la so NT");
	}

}
