package Bai5_TranPhamHaiDang_For;

import java.util.Scanner;

public class tinhS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		System.out.println("Nhap x:");
		double x = sc.nextDouble();
		double s = x * x + 1;
		double S = 1;
		if(n != 0)
		{
			for(int i = 1; i <= n; i++)
			{
				S *= s;
			}
		}
		System.out.println("S = (x * x + 1) mu n = " + S);
	}

}
