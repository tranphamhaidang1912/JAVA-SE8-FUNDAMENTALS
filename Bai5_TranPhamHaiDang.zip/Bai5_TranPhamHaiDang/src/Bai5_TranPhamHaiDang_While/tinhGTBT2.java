package Bai5_TranPhamHaiDang_While;

import java.util.Scanner;

public class tinhGTBT2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int tong = 0;
		int i = 1;
		while(i <= n)
		{
			if(ktSoNT(i)) 
				tong += i;
			i++;
		}		
		System.out.println("Tong cac so nguyen to nho hon hay bang n = " + tong);
		
	}
	public static boolean ktSoNT(int n) {
		// TODO Auto-generated method stub

		int dem = 0;
		int i = 1;
		while(i <= n)
		{
			if(n % i == 0)
			{
				++dem;
				if(dem > 2) break;
			}
			i++;
		}	
		if(dem == 2) return true;
		else return false;
	}

}
