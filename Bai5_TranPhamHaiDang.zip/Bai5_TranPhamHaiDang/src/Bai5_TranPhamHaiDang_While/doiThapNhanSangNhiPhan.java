package Bai5_TranPhamHaiDang_While;

import java.util.Scanner;

public class doiThapNhanSangNhiPhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		doiThapPhanSangNhiPhan(n);
	}
	private static void doiThapPhanSangNhiPhan(int n) {
		// TODO Auto-generated method stub

		if(n != 0)
		{
			doiThapPhanSangNhiPhan(n/2);
			System.out.print(n%2);
		}
		else System.out.print(0);
	}
}
