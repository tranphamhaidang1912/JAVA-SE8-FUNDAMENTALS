package Bai5_TranPhamHaiDang_While;

import java.util.Scanner;

public class inBangCuuChuong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Tu so:");
		int tuSo = sc.nextInt();
		System.out.println("Den so:");
		int denSo = sc.nextInt();
		int i = 1;
		while(i <= 9)
		{
			int j = tuSo;
			while(j <= denSo)
			{
				System.out.print(j + " x " + i + " = " + j * i + "\t");
				j++;
			}
			System.out.println("\n");
			i++;
		}
	}

}
