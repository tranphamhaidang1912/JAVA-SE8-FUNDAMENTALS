package Bai5_TranPhamHaiDang_While;

import java.util.Scanner;

public class ktSoNT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int dem = 0;
		int i = 1;
		while(i <= n)
		{
			if(n % i == 0)
			{
				++dem;
				if(dem > 2) break;
			}
			i++;
		}		
		if(dem == 2) 
			System.out.println(n + " La so NT");
		else
			System.out.println(n + " Khong la so NT");
	}

}
