package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class timKiemTrongMang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n");
		int n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Nhap gia tri cho cac phan tu trong mang");
		for(int i = 0; i < a.length; i++)
			a[i] = sc.nextInt();
		System.out.println("Nhap x:");
		int x = sc.nextInt();
		if(timX(a, x) == true)
			System.out.println("x = " + x + " xuat hien trong mang");
		else
			System.out.println("x = " + x + " khong xuat hien trong mang");
	}
	public static boolean timX(int[] a, int x) {
		
		for(int i = 0; i < a.length; i++)
			if(a[i] == x)
				return true;
		return false;
	}
}
