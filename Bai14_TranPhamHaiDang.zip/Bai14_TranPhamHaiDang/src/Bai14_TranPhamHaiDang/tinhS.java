package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class tinhS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		System.out.println("Nhap x:");
		double x = sc.nextDouble();
		System.out.println("S = (x * x + 1) mu n = " + tinhS(x, n));
	}
	public static double tinhS(double x, int n) {
		double s = x * x + 1;
		return tinhLuyThua(s, n);
	}
	public static double tinhLuyThua(double x, int n) {		
		
		double S = 1;
		for(int i = 1; i <= n; i++)
			S *= x;
		return S;
	}
}
