package Bai14_TranPhamHaiDang;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

public class xuLyMaTranVuong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap dong va cot m:");
		int m = sc.nextInt();
		int[][] a = new int[m][m];		
		Random random = new Random();
		for(int i = 0; i < a.length; i++)
			for(int j = 0; j < a[i].length; j++)
				a[i][j] = random.nextInt(20);
		xuLyMaTranVuongA(a);
		
		int[][] b = new int[m][m];
		System.out.println("Nhap gia tri cho cac phan tu ma tran vuong b:");
		for(int i = 0; i < b.length; i++)
			for(int j = 0; j < b[i].length; j++)
				b[i][j] = sc.nextInt();
		xuLyMaTranVuongB(b);
		
		int[][] c = new int[m][m];
		for(int i = 0; i < c.length; i++)
			for(int j = 0; j < c[i].length; j++)
				c[i][j] = a[i][j] + b[i][j];
		System.out.println("Mang tran vuong c:");
		for(int i = 0; i < c.length; i++)
		{
			for(int j = 0; j < c[i].length; j++)
				System.out.print(c[i][j] + " ");
			System.out.println();
		}		
		System.out.println("Nhap vao vi tri cua 1 cot k bat ki trong ma tran vuong c: ");
		int k = sc.nextInt();
		xuLyMaTranVuongC(c, a, b, k);
	}
	public static boolean ktSNT(int x) {
		// TODO Auto-generated method stub

		if(x < 2) return false;
		for(int i = 2; i <= Math.sqrt(x); i++)
		{
			if(x % i == 0)
				return false;
		}
		return true;
	}
	public static void xuLyMaTranVuongA(int[][] a) {
		
		System.out.println("Mang tran vuong a:");
		int tongDuongCheoChinh = 0;
		int min = a[0][0];
		int max = a[0][0];
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				System.out.print(a[i][j] + " ");
				if(i == j)
				{
					tongDuongCheoChinh += a[i][j];
					if(a[i][j] < min)
						min = a[i][j];
					if(a[i][j] > max)
						max = a[i][j];
				}
			}			
			System.out.println();
		}
		System.out.println("Tong cac gia tri tren duong cheo chinh ma tran vuong a: " + tongDuongCheoChinh);
		System.out.println("Gia tri nho nhat tren duong cheo chinh ma tran vuong a: " + min);
		System.out.println("Gia tri lon nhat tren duong cheo chinh ma tran vuong a: " + max);
		System.out.println("Tat ca cac so nguyen to trong ma tran vuong a:");
		int demSNT = 0;
		for(int i = 0; i < a.length; i++)
			for(int j = 0; j < a[i].length; j++)
				if(ktSNT(a[i][j]) == true)
				{
					System.out.println(a[i][j] + " (dong " + i + ", cot " + j + ")");
					++demSNT;
				}					
		if(demSNT == 0)
			System.out.println("Khong co so nguyen to nao trong ma tran vuong a");	
	}
	public static void xuLyMaTranVuongB(int[][] b) {
		
		System.out.println("Mang tran vuong b:");
		boolean doiXung = true;
		for(int i = 0; i < b.length; i++)
		{
			for(int j = 0; j < b[i].length; j++)
			{
				System.out.print(b[i][j] + " ");
				if(b[i][j] != b[j][i])
					doiXung = false;
			}
			System.out.println();
		}
		if(doiXung == true)
			System.out.println("Ma tran vuong b doi xung qua duong cheo chinh");
		else System.out.println("Ma tran vuong b khong doi xung qua duong cheo chinh");
	}
	public static void xuLyMaTranVuongC(int[][] c, int[][] a, int[][] b, int k) {
		
		
		boolean tangDan = true;
		boolean giamDan = true;
		for(int i = 0; i < c.length; i++)
		{
			if(i != c.length - 1)
			{
				if(tangDan == true && c[i][k] > c[i+1][k])
					tangDan = false;
				if(giamDan == true && c[i][k] < c[i+1][k])
					giamDan = false;
			}			
		}	
		if(tangDan == true)
			System.out.println("Gia tri cua cac phan tu trong ma tran c co cot " + k + " tang dan");
		else System.out.println("Gia tri cua cac phan tu trong ma tran c co cot " + k + " khong tang dan");
		if(giamDan == true)
			System.out.println("Gia tri cua cac phan tu trong ma tran c co cot " + k + " giam dan");
		else System.out.println("Gia tri cua cac phan tu trong ma tran c co cot " + k + " khong giam dan");
	}
}
