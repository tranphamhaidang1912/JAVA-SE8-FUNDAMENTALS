package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class kiemTraMangMotChieu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n");
		int n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Nhap gia tri cho cac phan tu trong mang");
		for(int i = 0; i < a.length; i++)
			a[i] = sc.nextInt();
		if(ktMangTangDan(a) == true)
			System.out.println("Mang tang dan");
		else System.out.println("Mang khong tang dan");
		if(ktMangGiamDan(a) == true)
			System.out.println("Mang giam dan");
		else System.out.println("Mang khong giam dan");
		int phanTuDauTienTrongMangCoTanCungLa6 = phanTuDauTienTrongMangCoTanCungLa6(a);
		if(phanTuDauTienTrongMangCoTanCungLa6 != -1)
			System.out.println("Phan tu dau tien trong mang co tan cung la 6 la: " + phanTuDauTienTrongMangCoTanCungLa6);
		else System.out.println("Mang khong co phan tu nao co tan cung la 6");
	}
	public static boolean ktMangTangDan(int[] a) {
		int dem = 0;
		for(int i = 0; i < a.length; i++)
			if(i != (a.length - 1))
			{
				if(a[i] > a[i+1])
					return false;
				if(a[i] == a[i+1])
				{
					dem++;
					if(dem == a.length)
						return false;
				}
			}			
		return true;
	}
	public static boolean ktMangGiamDan(int[] a) {	
		int dem = 0;
		for(int i = 0; i < a.length; i++)
			if(i != (a.length - 1))
			{
				if(a[i] < a[i+1])
					return false;
				if(a[i] == a[i+1])
				{
					dem++;
					if(dem == a.length)
						return false;
				}
			}			
		return true;
	}
	public static int phanTuDauTienTrongMangCoTanCungLa6(int[] a) {
		for(int i = 0; i < a.length; i++)
			if(a[i] % 10 == 6)
				return i;		
		return -1;
	}
}
