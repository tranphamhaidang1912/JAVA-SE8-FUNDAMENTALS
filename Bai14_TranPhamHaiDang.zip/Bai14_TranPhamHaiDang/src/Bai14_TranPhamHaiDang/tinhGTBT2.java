package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class tinhGTBT2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		System.out.println("Tong cac so nguyen to nho hon hay bang n = " + tongSNT(n));
		
	}
	public static int  tongSNT(int n) {
		int tong = 0;
		for(int i = 1; i <= n; i++)
		{
			if(ktSNT(i)) 
				tong += i;
		}
		return tong;
	}
	public static boolean ktSNT(int n) {
		// TODO Auto-generated method stub

		if(n < 2) return false;
		for(int i = 2; i <= Math.sqrt(n); i++)
		{
			if(n % i == 0)
				return false;
		}
		return true;
	}

}
