package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class tinhGiaiThua {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		long n = sc.nextInt();
		System.out.println("Giai thua n! = " + tinhGiaiThua1(n));
		System.out.println("Giai thua n!! = " + tinhGiaiThua2(n));
	}
	public static long tinhGiaiThua1(long n) {
		
		if(n == 0) return 1;
		long giaiThua1 = 1;
		for(long i = 2; i <= n; i++)
			giaiThua1 *= i;
		return giaiThua1;
	}
	public static long tinhGiaiThua2(long n) {
		
		if(n == 0) return 1;
		long giaiThua2 = 1;
		if(n % 2 == 0)
		{
			giaiThua2 = 2;
			for(long i = 4; i <= n; i++)
				if(i % 2 == 0)
					giaiThua2 *= i;
		}
		else
		{
			for(long i = 3; i <= n; i++)
				if(i % 2 != 0)				
					giaiThua2 *= i;											
		}
		return giaiThua2;
	}
}
