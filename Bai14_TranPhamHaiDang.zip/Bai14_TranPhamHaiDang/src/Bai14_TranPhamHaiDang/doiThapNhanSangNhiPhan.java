package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class doiThapNhanSangNhiPhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		StringBuilder s = new StringBuilder();
		System.out.println(doiThapPhanSangNhiPhan(s, n));	
	}
	public static StringBuilder doiThapPhanSangNhiPhan(StringBuilder s, int n) {
		// TODO Auto-generated method stub
		if(n != 0)
		{
			doiThapPhanSangNhiPhan(s, n / 2);
			s.append(n % 2);
		}
		return s;
	}
}
