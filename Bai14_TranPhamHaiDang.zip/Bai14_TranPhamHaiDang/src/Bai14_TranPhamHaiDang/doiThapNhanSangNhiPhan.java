package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class doiThapNhanSangNhiPhan {

	static String s = "";
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		
		System.out.println(doiThapPhanSangNhiPhan(n));	
	}
	public static String doiThapPhanSangNhiPhan(int n) {
		// TODO Auto-generated method stub

		if(n != 0)
		{
			doiThapPhanSangNhiPhan(n / 2);
			s += (n % 2);
		}
		else 
			s += 0;
		return s;
	}
}
