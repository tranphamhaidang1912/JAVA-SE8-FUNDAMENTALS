package Bai14_TranPhamHaiDang;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class xuLyMangNgauNhien {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap n:");
		int n = Integer.parseInt(input.readLine());
		int[] a = new int[n];
		xuLyMangNgauNhien(a);
	}
	public static void xuLyMangNgauNhien(int[] a) {
		Random random = new Random();
		System.out.println("Mang ngau nhien:");
		int tong = 0;
		for(int i = 0; i < a.length; i++)
		{
			a[i] = random.nextInt(10);
			tong += a[i];
			System.out.print(a[i] + " ");
		}			
		System.out.println("\nTong = " + tong);
	}
}
