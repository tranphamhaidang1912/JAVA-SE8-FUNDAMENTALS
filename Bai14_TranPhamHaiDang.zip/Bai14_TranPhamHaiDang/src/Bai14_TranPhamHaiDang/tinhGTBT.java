package Bai14_TranPhamHaiDang;

import java.util.Scanner;

public class tinhGTBT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int[] kq = tinhGTBT(n);
		System.out.println("Ket qua A = " + kq[0]);
		System.out.println("Ket qua B = " + kq[1]);
		System.out.println("Ket qua C = " + kq[2]);
		System.out.println("Ket qua D = " + kq[3]);
 	}
	public static int[] tinhGTBT(int n) {
		
		int[] a = new int[4];
		a[0] = 0;
		a[1] = 0;
		a[2] = 1;
		a[3] = 1;
		for(int i = 1; i <= n; i++)
		{
			if(i % 2 != 0)
				a[0] += i;
			else a[1] += i;
			a[2] *= i;
			if(i % 3 == 0)
				a[3] *= i;
		}
		return a;
	}
}
