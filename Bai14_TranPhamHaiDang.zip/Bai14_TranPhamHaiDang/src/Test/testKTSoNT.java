package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.ktSoNT;

public class testKTSoNT {

	@Test
	public void testKTSoNT1() {
		boolean ac = ktSoNT.ktSNT(23);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT2() {
		boolean ac = ktSoNT.ktSNT(11);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT3() {
		boolean ac = ktSoNT.ktSNT(17);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT4() {
		boolean ac = ktSoNT.ktSNT(5);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT5() {
		boolean ac = ktSoNT.ktSNT(67);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT6() {
		boolean ac = ktSoNT.ktSNT(12);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT7() {
		boolean ac = ktSoNT.ktSNT(8);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT8() {
		boolean ac = ktSoNT.ktSNT(30);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT9() {
		boolean ac = ktSoNT.ktSNT(100);
		assertTrue(ac);
	}

	@Test
	public void testKTSoNT10() {
		boolean ac = ktSoNT.ktSNT(69);
		assertTrue(ac);
	}

}
