package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.doiNhiPhanSangThapPhan;
import Bai14_TranPhamHaiDang.doiThapNhanSangNhiPhan;

public class testDoiThapPhanSangNhiPhan {

	@Test
	public void testDoiThapPhanSangNhiPhan1() {
		int ex = 1000;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(8));
		System.out.println(ac);
		assertEquals(ex, ac);
	}

	@Test
	public void testDoiThapPhanSangNhiPhan2() {
		int ex = 1010;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(10));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan3() {
		int ex = 1110;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(14));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan4() {
		int ex = 1001;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(9));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan5() {
		int ex = 1111;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(15));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan6() {
		int ex = 10;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(22));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan7() {
		int ex = 11;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(37));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan8() {
		int ex = 100;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(19));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan9() {
		int ex = 101;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(43));
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan10() {
		int ex = 110;
		int ac = Integer.parseInt(doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(54));
		assertEquals(ex, ac);
	}
}
