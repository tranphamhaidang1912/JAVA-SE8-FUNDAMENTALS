package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.doiNhiPhanSangThapPhan;
import Bai14_TranPhamHaiDang.doiThapNhanSangNhiPhan;

public class testDoiThapPhanSangNhiPhan {

	@Test
	public void testDoiThapPhanSangNhiPhan1() {
		StringBuilder ex = new StringBuilder("1000");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 8);
		assertEquals(ex.toString(), ac.toString());
	}

	@Test
	public void testDoiThapPhanSangNhiPhan2() {
		StringBuilder ex = new StringBuilder("1010");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 10);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan3() {
		StringBuilder ex = new StringBuilder("1110");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 14);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan4() {
		StringBuilder ex = new StringBuilder("1001");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 9);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan5() {
		StringBuilder ex = new StringBuilder("1111");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 15);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan6() {
		StringBuilder ex = new StringBuilder("10");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 22);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan7() {
		StringBuilder ex = new StringBuilder("11");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 37);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan8() {
		StringBuilder ex = new StringBuilder("100");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 19);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan9() {
		StringBuilder ex = new StringBuilder("101");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 43);
		assertEquals(ex.toString(), ac.toString());
	}
	
	@Test
	public void testDoiThapPhanSangNhiPhan10() {
		StringBuilder ex = new StringBuilder("110");
		StringBuilder s = new StringBuilder();
		StringBuilder ac = doiThapNhanSangNhiPhan.doiThapPhanSangNhiPhan(s, 54);
		assertEquals(ex.toString(), ac.toString());
	}
}
