package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.doiNhiPhanSangThapPhan;

public class testDoiNhiPhanSangThapPhan {

	@Test
	public void testDoiNhiPhanSangThapPhan1() {
		int ex = 8;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(1000);
		assertEquals(ex, ac);
	}

	@Test
	public void testDoiNhiPhanSangThapPhan2() {
		int ex = 10;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(1010);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan3() {
		int ex = 14;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(1110);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan4() {
		int ex = 9;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(1001);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan5() {
		int ex = 15;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(1111);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan6() {
		int ex = 22;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(10);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan7() {
		int ex = 37;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(11);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan8() {
		int ex = 19;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(100);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan9() {
		int ex = 43;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(101);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testDoiNhiPhanSangThapPhan10() {
		int ex = 54;
		int ac = doiNhiPhanSangThapPhan.doiNhiPhanSangThapPhan(110);
		assertEquals(ex, ac);
	}
}
