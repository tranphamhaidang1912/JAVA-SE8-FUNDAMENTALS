package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhA;

public class testTinhA {

	@Test
	public void testTinhA1() {
		double ex = 4;
		double ac = tinhA.tinhA(1, 1);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhA2() {
		double ex = 218;
		double ac = tinhA.tinhA(-3, 2);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA3() {
		double ex = 2;
		double ac = tinhA.tinhA(0, 100);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA4() {
		double ex = 28;
		double ac = tinhA.tinhA(-1, 3);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA5() {
		double ex = 112.53125;
		double ac = tinhA.tinhA(1.5, 3);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA6() {
		double ex = 0;
		double ac = tinhA.tinhA(8, -4);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA7() {
		double ex = 0;
		double ac = tinhA.tinhA(2, -1000);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA8() {
		double ex = 0;
		double ac = tinhA.tinhA(-4, -9);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA9() {
		double ex = 0;
		double ac = tinhA.tinhA(-101, -80);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhA10() {
		double ex = 0;
		double ac = tinhA.tinhA(-4, -4);
		assertEquals(ex, ac, 0);
	}


}
