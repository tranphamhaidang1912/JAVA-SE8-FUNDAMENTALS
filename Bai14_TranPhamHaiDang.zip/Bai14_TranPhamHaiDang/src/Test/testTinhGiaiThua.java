package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhGiaiThua;

public class testTinhGiaiThua {

	@Test
	public void testTinhGiaiThua1() {
		long ex1 = 3628800;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(10);
		long ex2 = 3840;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(10);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua2() {
		long ex1 = 121645100408832000l;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(19);
		long ex2 = 654729075;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(19);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua3() {
		long ex1 = 40320;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(8);
		long ex2 = 384;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(8);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua4() {
		long ex1 = 39916800;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(11);
		long ex2 = 10395;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(11);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua5() {
		long ex1 = 720;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(6);
		long ex2 = 48;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(6);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua6() {
		long ex1 = 20;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(4);
		long ex2 = 10;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(4);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua7() {
		long ex1 = 1307674368999l;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(15);
		long ex2 = 2027000;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(15);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua8() {
		long ex1 = 355687428096567l;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(17);
		long ex2 = 34459444;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(17);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua9() {
		long ex1 = 479001345;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(12);
		long ex2 = 46543;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(12);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

	@Test
	public void testTinhGiaiThua10() {
		long ex1 = 362777;
		long ac1 = tinhGiaiThua.tinhGiaiThua1(9);
		long ex2 = 940;
		long ac2 = tinhGiaiThua.tinhGiaiThua2(9);
		assertEquals(ex1, ac1);
		assertEquals(ex2, ac2);
	}

}
