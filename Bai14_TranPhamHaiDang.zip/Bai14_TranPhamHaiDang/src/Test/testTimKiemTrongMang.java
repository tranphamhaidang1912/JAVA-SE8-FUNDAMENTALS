package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.timKiemTrongMang;

public class testTimKiemTrongMang {

	@Test
	public void testTimX1() {
		int[] a = {1, 2, 3, 4, 5};
		boolean ac = timKiemTrongMang.timX(a, 4);
		assertTrue(ac);
	}

	@Test
	public void testTimX2() {
		int[] a = {10, 9, 8, 7, 6};
		boolean ac = timKiemTrongMang.timX(a, 6);
		assertTrue(ac);
	}

	@Test
	public void testTimX3() {
		int[] a = {55, 34, 11, 70, 100};
		boolean ac = timKiemTrongMang.timX(a, 11);
		assertTrue(ac);
	}
	
	@Test
	public void testTimX4() {
		int[] a = {27, 18, 1, 2, 30};
		boolean ac = timKiemTrongMang.timX(a, 27);
		assertTrue(ac);
	}
	
	@Test
	public void testTimX5() {
		int[] a = {13, 69, 99, 11, 10};
		boolean ac = timKiemTrongMang.timX(a, 69);
		assertTrue(ac);
	}
	
	@Test
	public void testTimX6() {
		int[] a = {11, 12, 13, 14, 15};
		boolean ac = timKiemTrongMang.timX(a, 22);
		assertFalse(ac);
	}
	
	@Test
	public void testTimX7() {
		int[] a = {24, 32, 73, 54, 95};
		boolean ac = timKiemTrongMang.timX(a, 99);
		assertFalse(ac);
	}
	
	@Test
	public void testTimX8() {
		int[] a = {101, 1000, 45, 300, 11};
		boolean ac = timKiemTrongMang.timX(a, 10);
		assertFalse(ac);
	}
	
	@Test
	public void testTimX9() {
		int[] a = {76, 30, 34, 57, 66};
		boolean ac = timKiemTrongMang.timX(a, 33);
		assertFalse(ac);
	}
	
	@Test
	public void testTimX10() {
		int[] a = {1, 10, 100, 1000, 10000};
		boolean ac = timKiemTrongMang.timX(a, 101);
		assertFalse(ac);
	}
}
