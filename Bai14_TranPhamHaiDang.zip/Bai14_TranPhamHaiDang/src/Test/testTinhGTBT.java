package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhGTBT;

public class testTinhGTBT {

	@Test
	public void testTinhGTBT1() {
		int[] ex_kq = {25, 30, 3628800 ,162};
		int[] ac_kq = tinhGTBT.tinhGTBT(10);
		assertArrayEquals(ex_kq, ac_kq);
	}

	@Test
	public void testTinhGTBT2() {
		int[] ex_kq = {9, 6, 120 ,3};
		int[] ac_kq = tinhGTBT.tinhGTBT(5);
		assertArrayEquals(ex_kq, ac_kq);
	}

	@Test
	public void testTinhGTBT3() {
		int[] ex_kq = {36, 42, 479001600 ,1944};
		int[] ac_kq = tinhGTBT.tinhGTBT(12);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT4() {
		int[] ex_kq = {4, 2, 6 ,3};
		int[] ac_kq = tinhGTBT.tinhGTBT(3);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT5() {
		int[] ex_kq = {9, 12, 720 ,18};
		int[] ac_kq = tinhGTBT.tinhGTBT(6);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT6() {
		int[] ex_kq = {1, 2, 3 ,4};
		int[] ac_kq = tinhGTBT.tinhGTBT(1);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT7() {
		int[] ex_kq = {5, 6, 7 ,8};
		int[] ac_kq = tinhGTBT.tinhGTBT(2);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT8() {
		int[] ex_kq = {9, 10, 11 ,12};
		int[] ac_kq = tinhGTBT.tinhGTBT(13);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT9() {
		int[] ex_kq = {13, 14, 15 ,16};
		int[] ac_kq = tinhGTBT.tinhGTBT(7);
		assertArrayEquals(ex_kq, ac_kq);
	}
	
	@Test
	public void testTinhGTBT10() {
		int[] ex_kq = {17, 18, 19 ,20};
		int[] ac_kq = tinhGTBT.tinhGTBT(9);
		assertArrayEquals(ex_kq, ac_kq);
	}
}
