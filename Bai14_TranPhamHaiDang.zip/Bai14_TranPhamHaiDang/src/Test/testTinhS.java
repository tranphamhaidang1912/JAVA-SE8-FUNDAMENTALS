package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhS;

public class testTinhS {

	@Test
	public void testTinhS1() {
		double ex = 125;
		double ac = tinhS.tinhS(2, 3);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testTinhS2() {
		double ex = 8;
		double ac = tinhS.tinhS(-1, 3);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS3() {
		double ex = 1;
		double ac = tinhS.tinhS(4, 0);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS4() {
		double ex = 1;
		double ac = tinhS.tinhS(0, 10);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS5() {
		double ex = 1.5625;
		double ac = tinhS.tinhS(0.5, 2);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS6() {
		double ex = 0;
		double ac = tinhS.tinhS(6, -3);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS7() {
		double ex = 0;
		double ac = tinhS.tinhS(5, -10);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS8() {
		double ex = 0;
		double ac = tinhS.tinhS(-2, -3);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS9() {
		double ex = 0;
		double ac = tinhS.tinhS(-4, -2);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testTinhS10() {
		double ex = 0;
		double ac = tinhS.tinhS(-5, -5);
		assertEquals(ex, ac, 0);
	}
}
