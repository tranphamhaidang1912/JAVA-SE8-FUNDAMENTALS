package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhBMI;

public class testTinhBMI {

	@Test
	public void testTinhBMI1() {
		double ex_tinhBMI = 18.73;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.55, 45) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertEquals(ex_tinhBMI, ac_tinhBMI, 0);
		assertEquals(ex_danhGiaBMI, ac_danhGiaBMI);
	}

	@Test
	public void testTinhBMI2() {
		double ex_tinhBMI = 19.53125;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.6, 50) * 100000.0) / 100000.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertEquals(ex_tinhBMI, ac_tinhBMI, 0);
		assertEquals(ex_danhGiaBMI, ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI3() {
		double ex_tinhBMI = 20.20;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.65, 55) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertEquals(ex_tinhBMI, ac_tinhBMI, 0);
		assertEquals(ex_danhGiaBMI, ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI4() {
		double ex_tinhBMI = 20.761246;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.7, 60) * 1000000.0) / 1000000.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertEquals(ex_tinhBMI, ac_tinhBMI, 0);
		assertEquals(ex_danhGiaBMI, ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI5() {
		double ex_tinhBMI = 21.22;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.75, 65) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertEquals(ex_tinhBMI, ac_tinhBMI, 0);
		assertEquals(ex_danhGiaBMI, ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI6() {
		double ex_tinhBMI = 13.67;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.5, 30) * 1000000.0) / 1000000.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertFalse(ex_tinhBMI == ac_tinhBMI);
		assertFalse(ex_danhGiaBMI == ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI7() {
		double ex_tinhBMI = 16.89;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.45, 34) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertFalse(ex_tinhBMI == ac_tinhBMI);
		assertFalse(ex_danhGiaBMI == ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI8() {
		double ex_tinhBMI = 20.55;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.4, 40) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban thua can";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertFalse(ex_tinhBMI == ac_tinhBMI);
		assertFalse(ex_danhGiaBMI == ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI9() {
		double ex_tinhBMI = 13.71;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.35, 25) * 100.0) / 100.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertFalse(ex_tinhBMI == ac_tinhBMI);
		assertFalse(ex_danhGiaBMI == ac_danhGiaBMI);
	}
	
	@Test
	public void testTinhBMI10() {
		double ex_tinhBMI = 11.83477;
		double ac_tinhBMI = Math.round(tinhBMI.tinhBMI(1.3, 20) * 100000.0) / 100000.0;
		System.out.println(ac_tinhBMI);
		String ex_danhGiaBMI = "Ban binh thuong";
		String ac_danhGiaBMI = tinhBMI.danhGiaBMI(ac_tinhBMI);
		assertFalse(ex_tinhBMI == ac_tinhBMI);
		assertFalse(ex_danhGiaBMI == ac_danhGiaBMI);
	}
}
