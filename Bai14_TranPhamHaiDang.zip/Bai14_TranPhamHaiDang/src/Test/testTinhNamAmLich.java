package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhNamAmLich;

public class testTinhNamAmLich {

	@Test
	public void testTinhNamAmLich1() {
		String ex = "Giap Tuat";
		String ac = tinhNamAmLich.tinhNamAmLich(1994);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhNamAmLich2() {
		String ex = "Mau Thin";
		String ac = tinhNamAmLich.tinhNamAmLich(1988);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhNamAmLich3() {
		String ex = "Quy Ty";
		String ac = tinhNamAmLich.tinhNamAmLich(2013);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhNamAmLich4() {
		String ex = "Ky Dau";
		String ac = tinhNamAmLich.tinhNamAmLich(1969);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhNamAmLich5() {
		String ex = "Dinh Suu";
		String ac = tinhNamAmLich.tinhNamAmLich(1997);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhNamAmLich6() {
		String ex = "Quy Mui";
		String ac = tinhNamAmLich.tinhNamAmLich(2002);
		assertFalse(ex == ac);
	}

	@Test
	public void testTinhNamAmLich7() {
		String ex = "Binh Tuat";
		String ac = tinhNamAmLich.tinhNamAmLich(2005);
		assertFalse(ex == ac);
	}

	@Test
	public void testTinhNamAmLich8() {
		String ex = "At Ty";
		String ac = tinhNamAmLich.tinhNamAmLich(1966);
		assertFalse(ex == ac);
	}

	@Test
	public void testTinhNamAmLich9() {
		String ex = "Ky Mui";
		String ac = tinhNamAmLich.tinhNamAmLich(1980);
		assertFalse(ex == ac);
	}

	@Test
	public void testTinhNamAmLich10() {
		String ex = "Canh Ty";
		String ac = tinhNamAmLich.tinhNamAmLich(1954);
		assertFalse(ex == ac);
	}

}
