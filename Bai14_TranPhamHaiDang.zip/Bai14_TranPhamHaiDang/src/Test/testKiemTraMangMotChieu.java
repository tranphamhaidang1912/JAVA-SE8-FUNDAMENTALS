package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.kiemTraMangMotChieu;

public class testKiemTraMangMotChieu {

	@Test
	public void testKiemTraMangMotChieu1() {
		int[] a = {1, 2, 3, 4, 5};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertTrue(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertFalse(ac_giamDan);
		int ex_firstIndex = -1;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}

	@Test
	public void testKiemTraMangMotChieu2() {
		int[] a = {5, 4, 3, 2, 1};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertFalse(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertTrue(ac_giamDan);
		int ex_firstIndex = -1;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu3() {
		int[] a = {3, 5, 4, 1, 6};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertFalse(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertFalse(ac_giamDan);
		int ex_firstIndex = 4;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu4() {
		int[] a = {8, 22, 56, 77, 90};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertTrue(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertFalse(ac_giamDan);
		int ex_firstIndex = 2;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu5() {
		int[] a = {100, 81, 40, 36, 9};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertFalse(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertTrue(ac_giamDan);
		int ex_firstIndex = 3;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu6() {
		int[] a = {1, 2, 3, 4, 5};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertFalse(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertTrue(ac_giamDan);
		int ex_firstIndex = 0;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu7() {
		int[] a = {5, 4, 3, 2, 1};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertTrue(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertFalse(ac_giamDan);
		int ex_firstIndex = 1;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu8() {
		int[] a = {3, 5, 4, 1, 6};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertTrue(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertTrue(ac_giamDan);
		int ex_firstIndex = 2;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu9() {
		int[] a = {8, 22, 56, 77, 90};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertFalse(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertTrue(ac_giamDan);
		int ex_firstIndex = 3;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
	
	@Test
	public void testKiemTraMangMotChieu10() {
		int[] a = {100, 81, 40, 36, 9};
		boolean ac_tangDan = kiemTraMangMotChieu.ktMangTangDan(a);
		assertTrue(ac_tangDan);
		boolean ac_giamDan = kiemTraMangMotChieu.ktMangGiamDan(a);
		assertFalse(ac_giamDan);
		int ex_firstIndex = 4;
		int ac_firstIndex = kiemTraMangMotChieu.phanTuDauTienTrongMangCoTanCungLa6(a);
		assertEquals(ex_firstIndex, ac_firstIndex);
	}
}
