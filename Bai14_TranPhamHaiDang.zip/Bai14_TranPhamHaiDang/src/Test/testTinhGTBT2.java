package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai14_TranPhamHaiDang.tinhGTBT2;

public class testTinhGTBT2 {

	@Test
	public void testTinhGTBT21() {
		int ex = 17;
		int ac = tinhGTBT2.tongSNT(9);
		assertEquals(ex, ac);
	}

	@Test
	public void testTinhGTBT22() {
		int ex = 10;
		int ac = tinhGTBT2.tongSNT(5);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT23() {
		int ex = 41;
		int ac = tinhGTBT2.tongSNT(16);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT24() {
		int ex = 77;
		int ac = tinhGTBT2.tongSNT(22);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT25() {
		int ex = 100;
		int ac = tinhGTBT2.tongSNT(24);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT26() {
		int ex = 11;
		int ac = tinhGTBT2.tongSNT(99);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT27() {
		int ex = 12;
		int ac = tinhGTBT2.tongSNT(85);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT28() {
		int ex = 13;
		int ac = tinhGTBT2.tongSNT(73);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT29() {
		int ex = 14;
		int ac = tinhGTBT2.tongSNT(66);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testTinhGTBT210() {
		int ex = 15;
		int ac = tinhGTBT2.tongSNT(50);
		assertEquals(ex, ac);
	}
}
