package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhNhietDo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap loai nhiet do:");
		String loaiNhietDo = sc.nextLine();
		System.out.println("Nhap nhiet do");
		double nhietDo = sc.nextDouble();
		double nhietDoSauKhiDoi = 0;
		if(loaiNhietDo.equals("C")) 
			nhietDoSauKhiDoi = ((nhietDo * 9) / 5) + 32;
		else nhietDoSauKhiDoi = (5 *(nhietDo - 32)) / 9;
		System.out.println("Nhiet do sau khi doi la: " + nhietDoSauKhiDoi);
	}

}
