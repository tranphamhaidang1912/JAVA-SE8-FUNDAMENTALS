package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhThueThuNhapCaNhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Tong thu nhap trong nam:");
		double tongThuNhapCaNhan = sc.nextDouble();
		System.out.println("So nguoi phu thuoc:");
		int soNguoiPhuThuoc = sc.nextInt();
		double soTienGiamTru = (9000000 * 12) + (soNguoiPhuThuoc * 3600000 * 12);
		double soTienChiuThue = 250000000 - soTienGiamTru;
		double tienThuePhaiNop = 0;
		final int bac1 = 60000000;
		final int bac2 = 120000000;
		final int bac3 = 216000000;
		final int bac4 = 384000000;
		final int bac5 = 624000000;
		final int bac6 = 960000000;
		if(soTienChiuThue <= bac1) tienThuePhaiNop = soTienChiuThue * 0.05;
		else if(soTienChiuThue <= bac2) tienThuePhaiNop = (soTienChiuThue - bac1) * 0.1 + bac1 * 0.05;
		else if(soTienChiuThue <= bac3) tienThuePhaiNop = (soTienChiuThue - bac2) * 0.15 + bac2 * 0.1 + bac1 * 0.05;
		else if(soTienChiuThue <= bac4) tienThuePhaiNop = (soTienChiuThue - bac3) * 0.2 + bac3 * 0.15 + bac2 * 0.1 + bac1 * 0.05;
		else if(soTienChiuThue <= bac5) tienThuePhaiNop = (soTienChiuThue - bac4) * 0.25 + bac4 * 0.2 + bac3 * 0.15 + bac2 * 0.1 + bac1 * 0.05;
		else if(soTienChiuThue <= bac6) tienThuePhaiNop = (soTienChiuThue - bac5) * 0.3 + bac5 * 0.25 + bac4 * 0.2 + bac3 * 0.15 + bac2 * 0.1 + bac1 * 0.05;
		else tienThuePhaiNop = (soTienChiuThue - bac6) * 0.35 + bac6 * 0.3 + bac5 * 0.25 + bac4 * 0.2 + bac3 * 0.15 + bac2 * 0.1 + bac1 * 0.05;
		System.out.println("So tien giam tru: " + String.format("%.2f", soTienGiamTru));
		System.out.println("So tien chiu thue: " + String.format("%.2f", soTienChiuThue));
		System.out.println("Tien thue phai nop: " + String.format("%.2f", tienThuePhaiNop));
	}

}
