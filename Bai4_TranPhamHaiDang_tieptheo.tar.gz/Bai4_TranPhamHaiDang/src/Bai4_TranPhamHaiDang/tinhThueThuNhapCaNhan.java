package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhThueThuNhapCaNhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Tong thu nhap trong nam:");
		double tongThuNhapCaNhan = sc.nextDouble();
		System.out.println("So nguoi phu thuoc:");
		int soNguoiPhuThuoc = sc.nextInt();
		double soTienGiamTru = (9000000 * 12) + (soNguoiPhuThuoc * 3600000 * 12);
		double soTienChiuThue = 250000000 - soTienGiamTru;
		double tienThuePhaiNop = (soTienChiuThue - 60000000) * 0.1 + 60000000 * 0.05;
		System.out.println("So tien giam tru: " + String.format("%.2f", soTienGiamTru));
		System.out.println("So tien chiu thue: " + String.format("%.2f", soTienChiuThue));
		System.out.println("Tien thue phai nop: " + String.format("%.2f", tienThuePhaiNop));
	}

}
