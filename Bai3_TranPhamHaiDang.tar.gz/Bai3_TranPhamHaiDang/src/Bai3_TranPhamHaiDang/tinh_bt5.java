package Bai3_TranPhamHaiDang;

public class tinh_bt5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 10;
		int y = 4;
		boolean equivalence = x == y;
		System.out.println("x == y is " + equivalence);
		
		boolean nonEquivalence = x != y;
		System.out.println("x != y is " + nonEquivalence);
		
		boolean lessThan = x < y;
		System.out.println("x < y is " + lessThan);
		
		boolean greaterThan = x > y;
		System.out.println("x > y is " + greaterThan);
		
		boolean lessOrEqualTo = x <= y;
		System.out.println("x <= y is " + lessOrEqualTo);
		
		boolean greaterOrEqualTo = x >= y;
		System.out.println("x >= y is " + greaterOrEqualTo);
	}

}
