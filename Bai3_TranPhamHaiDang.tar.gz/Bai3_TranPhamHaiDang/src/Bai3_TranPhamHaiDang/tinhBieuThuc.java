package Bai3_TranPhamHaiDang;

import java.util.Scanner;

public class tinhBieuThuc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap x:");
		int x = sc.nextInt();
		double S = 1 + x + x*x*x/3 + x*x*x*x*x/5;
		System.out.println("S = " + String.format("%.1f", S));
	}

}
