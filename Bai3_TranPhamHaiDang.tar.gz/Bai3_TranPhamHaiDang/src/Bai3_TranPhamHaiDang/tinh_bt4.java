package Bai3_TranPhamHaiDang;

public class tinh_bt4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 3;
		i++;
		System.out.println(i);
		
		++i;
		System.out.println(i);
		
		System.out.println(++i);
		
		System.out.println(i++);
		
		System.out.println(i);
	}

}
