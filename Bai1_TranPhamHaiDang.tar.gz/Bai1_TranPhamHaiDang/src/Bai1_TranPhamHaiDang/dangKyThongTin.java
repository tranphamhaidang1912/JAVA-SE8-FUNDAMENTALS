package Bai1_TranPhamHaiDang;

import java.util.Scanner;

public class dangKyThongTin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("******************************\n");
		System.out.println("Đăng ký thông tin học viên\n");
		System.out.println("******************************\n\n");
		System.out.println("Họ tên: ");
		String hoTen = sc.nextLine();
		System.out.println("Email: ");
		String email = sc.nextLine();
		System.out.println("------------------------------\n");
		System.out.println("--- Xin chào bạn " + hoTen + "!");
		System.out.println("--- Thông tin của bạn đã được ghi nhận\n");
		System.out.println("------------------------------");
	}

}
