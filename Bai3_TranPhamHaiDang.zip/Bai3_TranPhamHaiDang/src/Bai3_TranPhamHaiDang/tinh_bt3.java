package Bai3_TranPhamHaiDang;

public class tinh_bt3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int result = +1;
		System.out.println(result);
		
		result--;
		System.out.println(result);
		
		result++;
		System.out.println(result);
		
		result = -result;
		System.out.println(result);
		
		boolean success = false;
		System.out.println(success);
		System.out.println(!success);
	}

}
