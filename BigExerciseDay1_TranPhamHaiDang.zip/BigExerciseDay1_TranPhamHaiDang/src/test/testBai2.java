package test;

import static org.junit.Assert.*;

import org.junit.Test;

import BigExerciseDay1_TranPhamHaiDang.bai2;

public class testBai2 {

	@Test
	public void testBai2_1() {
		int ex = 1;
		int[][] a = {{1,2},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}

	@Test
	public void testBai2_2() {
		int ex = 2;
		int[][] a = {{1,-12},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_3() {
		int ex = 3;
		int[][] a = {{-6,-6},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_4() {
		int ex = 2;
		int[][] a = {{-18,2},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_5() {
		int ex = 0;
		int[][] a = {{1,2},{3,4}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_6() {
		int ex = 0;
		int[][] a = {{1,2},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_7() {
		int ex = 0;
		int[][] a = {{-24,2},{3,-6}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_8() {
		int ex = 1;
		int[][] a = {{1,2},{3,7}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_9() {
		int ex = 6;
		int[][] a = {{1,2},{3,5}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
	
	@Test
	public void testBai2_10() {
		int ex = 10;
		int[][] a = {{1,2},{3,10}};
		int ac = bai2.demSoAmChiaHetCho2_Cho3(a);
		assertEquals(ex, ac);
	}
}
