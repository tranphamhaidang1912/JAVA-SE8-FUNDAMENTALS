package test;

import static org.junit.Assert.*;

import org.junit.Test;

import BigExerciseDay1_TranPhamHaiDang.bai1;

public class testBai1 {

	@Test
	public void testBai1_1() {
		double ex = 1536;
		double ac = bai1.tinhCuocDichVu("M0", 1024);
		assertEquals(ex, ac, 0);
	}

	@Test
	public void testBai1_2() {
		double ex = 70000;
		double ac = bai1.tinhCuocDichVu("MAX", 2048);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_3() {
		double ex = 50000;
		double ac = bai1.tinhCuocDichVu("MAXS", 512);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_4() {
		double ex = 10512;
		double ac = bai1.tinhCuocDichVu("M10", 52224);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_5() {
		double ex = 120000;
		double ac = bai1.tinhCuocDichVu("M120", 409600);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_6() {
		double ex = 69000;
		double ac = bai1.tinhCuocDichVu("M0", 3333);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_7() {
		double ex = 10000;
		double ac = bai1.tinhCuocDichVu("MAX100", 15000);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_8() {
		double ex = 7700;
		double ac = bai1.tinhCuocDichVu("M10", 13141);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_9() {
		double ex = 300000;
		double ac = bai1.tinhCuocDichVu("MAX200", 204896);
		assertEquals(ex, ac, 0);
	}
	
	@Test
	public void testBai1_10() {
		double ex = 500000;
		double ac = bai1.tinhCuocDichVu("M0", 10000);
		assertEquals(ex, ac, 0);
	}
}
