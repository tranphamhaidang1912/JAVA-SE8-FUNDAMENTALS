package BigExerciseDay1_TranPhamHaiDang;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class bai4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			String[] s = new String[n];
			sc.nextLine();
			for(int i = 0; i < s.length; i++)
				s[i] = sc.nextLine();
			System.out.println("Mang chuoi vua nhap:");
			xuatMangChuoi(s);
			
			System.out.println("Phan tu chua chuoi co do dai dai nhat: ");
			int indexMaxLength = viTriPhanTuDaiNhat(s);
			System.out.println("s[" + indexMaxLength + "] = " + s[indexMaxLength]);
			
			System.out.println("Nhap chuoi bat ki:");
			String chuoiNhap = sc.nextLine();
			int index = viTriChuoiNhapVao(s, chuoiNhap);
			if(index != -1)
				System.out.println("Vi tri chuoi vua nhap trong mang chuoi: " + index);
			else
				System.out.println("Chuoi vua nhap khong co trong mang chuoi");
			
			System.out.println("Mang chuoi moi sau khi duoc copy tu mang chuoi hien tai:");
			String[] s_new = copyMangHienTaiVaoMangChuoiMoi(s, n);
			xuatMangChuoi(s_new);
			
			System.out.println("Mang chuoi moi sau khi duoc sap xep tang dan:");
			Arrays.sort(s_new);
			xuatMangChuoi(s_new);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static void xuatMangChuoi(String[] s) {
		for(int i = 0; i < s.length; i++)
			System.out.println("s[" + i + "] = " + s[i] + ", chieu dai = " + s[i].length());
	}
	public static int viTriPhanTuDaiNhat(String[] s) {
		int indexMaxLength = 0;
		for(int i = 0; i < s.length; i++)
			if(s[i].length() > s[indexMaxLength].length())
				indexMaxLength = i;
		return indexMaxLength;
	}
	public static int viTriChuoiNhapVao(String[] s, String chuoiNhap) {
		int index = -1;
		for(int i = 0; i < s.length; i++)
			if(s[i].equals(chuoiNhap))
			{
				index = i;
				return index;
			}
		return index;
	}
	public static String[] copyMangHienTaiVaoMangChuoiMoi(String[] s, int n) {
		String[] s_new = new String[n];
		System.arraycopy(s, 0, s_new, 0, s.length);
		return s_new;
	}
}
