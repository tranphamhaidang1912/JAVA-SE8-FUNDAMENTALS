package BigExerciseDay1_TranPhamHaiDang;

import java.util.Scanner;

public class bai1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap ten goi cuoc:");
			String tenGoiCuoc = sc.nextLine();
			System.out.println("Nhap dung luong da su dung:");
			int dungLuongDaSuDung = sc.nextInt();
			
			System.out.println("So cuoc phai tra:");
			double cuocPhaiTra = tinhCuocDichVu(tenGoiCuoc, dungLuongDaSuDung);
			System.out.println(cuocPhaiTra + " VND");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}	
	}
	public static double tinhCuocDichVu(String tenGoiCuoc, int dungLuongDaSuDung) {
		double cuocPhaiTra = 0;
		switch (tenGoiCuoc) {
		case "M0":
			cuocPhaiTra = 1.5 * dungLuongDaSuDung;		
			break;
		case "M10":
			if(dungLuongDaSuDung < 50 * 1024)
				cuocPhaiTra = 10000;
			else 
				cuocPhaiTra = 10000 + 0.5 * (dungLuongDaSuDung - 50 * 1024);
			break;
		case "M25":
			if(dungLuongDaSuDung < 150 * 1024)
				cuocPhaiTra = 25000;
			else 
				cuocPhaiTra = 25000 + 0.5 * (dungLuongDaSuDung - 150 * 1024);
			break;
		case "M50":
			if(dungLuongDaSuDung < 500 * 1024)
				cuocPhaiTra = 50000;
			else 
				cuocPhaiTra = 50000 + 0.5 * (dungLuongDaSuDung - 500 * 1024);
			break;
		case "M120":
			if(dungLuongDaSuDung < 1500 * 1024)
				cuocPhaiTra = 120000;
			else 
				cuocPhaiTra = 120000 + 0.5 * (dungLuongDaSuDung - 1500 * 1024);
			break;
		case "MAX":
			cuocPhaiTra = 70000;
			break;
		case "MAX100":
			cuocPhaiTra = 100000;
			break;
		case "MAX200":
			cuocPhaiTra = 200000;
			break;
		case "MAXS":
			cuocPhaiTra = 50000;
			break;
		default:
			break;
		}
		return cuocPhaiTra;
	}
}
