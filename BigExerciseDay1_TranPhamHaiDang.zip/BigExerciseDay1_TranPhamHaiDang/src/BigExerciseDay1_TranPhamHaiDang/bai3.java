package BigExerciseDay1_TranPhamHaiDang;

import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

public class bai3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap loai ghe:");
			String loaiGhe = sc.nextLine();
			System.out.println("Nhap tong so ve muon mua:");
			int tongSoVe = sc.nextInt();
			System.out.println("Ve nguoi lon:");
			int veNguoiLon = sc.nextInt();
			System.out.println("Ve tre em:");
			int veTreEm = sc.nextInt();
			System.out.println("Ve nguoi gia:");
			int veNguoiGia = sc.nextInt();
			
			double tienVeNguoiLon = 0;
			double tienVeTreEm = 0;
			double tienVeNguoiGia = 0;
			switch (loaiGhe) {
			case "A2T":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 129000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 129000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 129000);
				break;
			case "A2TL":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 128000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 128000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 128000);
				break;
			case "AnLT1":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 249000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 249000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 249000);
				break;
			case "AnLT2":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 218000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 218000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 218000);
				break;
			case "AnT1":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 202000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 202000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 202000);
				break;
			case "AnT2":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 172000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 172000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 172000);
				break;
			case "BnLT1":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 214000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 214000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 214000);
				break;
			case "BnLT2":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 189000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 189000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 189000);
				break;
			case "BnLT3":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 163000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 163000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 163000);
				break;
			case "BnT1":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 193000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 193000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 193000);
				break;
			case "BnT2":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 168000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 168000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 168000);
				break;
			case "BnT3":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 146000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 146000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 146000);
				break;
			case "GP":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 79000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 79000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 79000);
				break;
			case "NC":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 99000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 99000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 99000);
				break;
			case "NCL":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 116000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 116000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 116000);
				break;
			case "NM":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 129000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 129000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 129000);
				break;
			case "NML":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 155000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 155000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 155000);
				break;
			case "NML4V":
				tienVeNguoiLon = tinhTienVeNguoiLon(veNguoiLon, 171000);
				tienVeTreEm = tinhTienVeTreEm(veTreEm, 171000);
				tienVeNguoiGia = tinhTienVeNguoiGia(veNguoiLon, 171000);
				break;
			default:
				break;
			}
			
			System.out.println("Hoa don dat ve:");
			System.out.println("Tong so ve: " + tongSoVe + " ve");
			System.out.println("Ve nguoi lon: " + veNguoiLon + " ve. Thanh tien: " + tienVeNguoiLon + " vnd");
			System.out.println("Ve tre em: " + veTreEm + " ve. Thanh tien: " + tienVeTreEm + " vnd");
			System.out.println("Ve nguoi gia: " + veNguoiGia + " ve. Thanh tien: " + tienVeNguoiGia + " vnd");
			double tienVe = tienVeNguoiLon + tienVeTreEm + tienVeNguoiGia;
			System.out.println("Tong so tien: " + tienVe + " ve. Thanh tien: " + tienVeNguoiGia + " vnd");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi" + e.toString());
		}	
	}
	public static double tinhTienVeNguoiLon(int veNguoiLon, double giaVe) {
		return veNguoiLon * giaVe;
	}
	public static double tinhTienVeTreEm(int veTreEm, double giaVe) {
		return veTreEm * giaVe * 0.5;
	}
	public static double tinhTienVeNguoiGia(int veNguoiGia, double giaVe) {
		return veNguoiGia * giaVe * 0.75;
	}
}
