package BigExerciseDay1_TranPhamHaiDang;

import java.util.Scanner;

public class bai7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("1/Doi so thap phan sang so thap luc phan\n2/Doi so thap luc phan sang so thap phan");
			int chon = sc.nextInt();
			sc.nextLine();
			switch (chon) {
			case 1:
				System.out.println("Nhap so thap phan:");
				int thapPhan = sc.nextInt();
				StringBuilder s = new StringBuilder();
				System.out.println(doiThapPhanSangThapLucPhan(s, thapPhan));
				break;
			case 2:
				System.out.println("Nhap so thap luc phan:");
				String thapLucPhan  = sc.nextLine();
				System.out.println(doiThapLucPhanSangThapPhan(thapLucPhan));
				break;
			default:
				break;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static StringBuilder doiThapPhanSangThapLucPhan(StringBuilder s, int thapPhan) {
		// TODO Auto-generated method stub
		if(thapPhan != 0)
		{
			doiThapPhanSangThapLucPhan(s, thapPhan / 16);
			int soDu = thapPhan % 16;
			if(soDu > 9)
			{
				if(soDu == 10)
					s.append("A");
				else if(soDu == 11)
					s.append("B");
				else if(soDu == 12)
					s.append("C");
				else if(soDu == 13)
					s.append("D");
				else if(soDu == 14)
					s.append("E");
				else if(soDu == 15)
					s.append("F");
			}
			else s.append(soDu);
		}
		return s;
	}
	public static int doiThapLucPhanSangThapPhan(String thapLucPhan) {
		int soThapPhan = 0;
		int i = thapLucPhan.length() - 1;
		for(int soMu = 0; i >= 0; soMu++)
		{
			if(thapLucPhan.charAt(i) != '0')
			{
				if(thapLucPhan.charAt(i) == '1')
					soThapPhan += Math.pow(16, soMu);
				else if(thapLucPhan.charAt(i) == '2')
					soThapPhan += 2 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '3')
					soThapPhan += 3 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '4')
					soThapPhan += 4 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '5')
					soThapPhan += 5 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '6')
					soThapPhan += 6 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '7')
					soThapPhan += 7 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '8')
					soThapPhan += 8 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == '9')
					soThapPhan += 9 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'A')
					soThapPhan += 10 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'B')
					soThapPhan += 11 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'C')
					soThapPhan += 12 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'D')
					soThapPhan += 13 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'E')
					soThapPhan += 14 * Math.pow(16,soMu);
				else if(thapLucPhan.charAt(i) == 'F')
					soThapPhan += 15 * Math.pow(16,soMu);
			}
			i--;
		}
		return soThapPhan;
	}
}
