package BigExerciseDay1_TranPhamHaiDang;

import java.util.Random;
import java.util.Scanner;

public class bai8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			int[] diemSinhVien = new int[n];
			Random random = new Random();
			for(int i = 0; i < diemSinhVien.length; i ++)
				diemSinhVien[i] = random.nextInt(101);
			int diem_0_9 = thongKeDiem(diemSinhVien, 0, 9);
			inThongKeDiem(0, 9, diem_0_9);
			int diem_10_19 = thongKeDiem(diemSinhVien, 10, 19);
			inThongKeDiem(10, 19, diem_10_19);
			int diem_20_29 = thongKeDiem(diemSinhVien, 20, 29);
			inThongKeDiem(20, 29, diem_20_29);
			int diem_30_39 = thongKeDiem(diemSinhVien, 30, 39);
			inThongKeDiem(30, 39, diem_30_39);
			int diem_40_49 = thongKeDiem(diemSinhVien, 40, 49);
			inThongKeDiem(40, 49, diem_40_49);
			int diem_50_59 = thongKeDiem(diemSinhVien, 50, 59);
			inThongKeDiem(50, 59, diem_50_59);
			int diem_60_69 = thongKeDiem(diemSinhVien, 60, 69);
			inThongKeDiem(60, 69, diem_60_69);
			int diem_70_79 = thongKeDiem(diemSinhVien, 70, 79);
			inThongKeDiem(70, 79, diem_70_79);
			int diem_80_89 = thongKeDiem(diemSinhVien, 80, 89);
			inThongKeDiem(80, 89, diem_80_89);
			int diem_90_100 = thongKeDiem(diemSinhVien, 90, 100);
			inThongKeDiem(90, 100, diem_90_100);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}	
	}
	public static int thongKeDiem(int[] diemSinhVien, int dau, int cuoi) {
		int dem = 0;
		for(int i = 0; i < diemSinhVien.length; i ++)
			if(diemSinhVien[i] >= dau && diemSinhVien[i] <= cuoi)
				dem++;
		return dem;
	}
	public static void inThongKeDiem(int dau, int cuoi, int dem) {
		System.out.print(dau + " - " + cuoi + ": ");
		for(int i = 1; i <= dem; i++)
			System.out.print("*");
		System.out.println();
	}
}
