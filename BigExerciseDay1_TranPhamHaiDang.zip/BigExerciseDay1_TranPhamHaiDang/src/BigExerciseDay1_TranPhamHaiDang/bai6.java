package BigExerciseDay1_TranPhamHaiDang;

public class bai6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			inBangCuuChuong();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}
		
	}
	public static void inBangCuuChuong() {
		int[][] cuuChuong = new int[10][10];
		for(int i = 1; i < cuuChuong.length; i++)
			for(int j = 1; j < cuuChuong[i].length; j++)
				cuuChuong[i][j] = i * j;
		System.out.println("Cuu Chuong\n");
		System.out.println("-----------------------------\n");
		for(int i = 1; i < cuuChuong.length; i++)
		{
			System.out.print(i + " | ");
			for(int j = 1; j < cuuChuong[i].length; j++)
				System.out.print(cuuChuong[i][j] + " ");
			System.out.println("\n");
		}
	}
}
