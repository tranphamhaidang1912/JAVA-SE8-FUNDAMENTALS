package BigExerciseDay1_TranPhamHaiDang;

import java.util.Random;

public class bai9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int[][] sodoku = new int[9][9];
			taoMaTranSodoku(sodoku);		
			for(int i = 0; i < sodoku.length; i++)
			{
				for(int j = 0; j < sodoku[i].length; j++)
					System.out.print(sodoku[i][j] + " ");
				System.out.println();
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}
	}
	public static void taoMaTranSodoku(int[][] sodoku) {
		Random random = new Random();
		while(true)
		{
			for(int i = 0; i < sodoku.length; i++)
			{
				for(int j = 0; j < sodoku[i].length; j++)
				{
					sodoku[i][j] = random.nextInt(10);
					if(sodoku[i][j] == 0) sodoku[i][j] = 1;
					for(int z = j - 1 ; z >= 0; z--)
						if(sodoku[i][j] == sodoku[i][z])
							j--;
					for(int z = i - 1; z >= 0; z--)
						if(sodoku[i][j] == sodoku[z][j])
							j--;
					if(ktKhoi33(sodoku, 0, 3, 0, 3) == true && ktKhoi33(sodoku, 0, 3, 3, 6) == true && ktKhoi33(sodoku, 0, 3, 6, 9) == true)
						if(ktKhoi33(sodoku, 3, 6, 0, 3) == true && ktKhoi33(sodoku, 3, 6, 3, 6) == true && ktKhoi33(sodoku, 3, 6, 6, 9) == true)
							if(ktKhoi33(sodoku, 6, 9, 0, 3) == true && ktKhoi33(sodoku, 6, 9, 3, 6) == true && ktKhoi33(sodoku, 6, 9, 6, 9) == true)
								break;
				}
			}
			
		}
	}
	public static boolean ktKhoi33(int[][] sodoku, int m, int n, int x, int y) {
		int[] temp = new int[9];
		int z = 0;
		for(int i = m; i < n; i++)
		{
			for(int j = x; j < y; j++)
			{
				temp[z] = sodoku[i][j];
				z++;
			}
		}
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				if(i != j && temp[i] == temp[j])
					return false;
			}
		}
		return true;
	}
}
