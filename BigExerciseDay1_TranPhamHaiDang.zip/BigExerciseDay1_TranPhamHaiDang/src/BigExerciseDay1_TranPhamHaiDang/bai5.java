package BigExerciseDay1_TranPhamHaiDang;

import java.util.Random;
import java.util.Scanner;

public class bai5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			
			int[] a = new int[n];
			taoMangNgauNhienMotChieu(a, n);
			System.out.println("Mang mot chieu ngau nhien vua tao:");
			for(int value : a)
				System.out.println(value);
			
			System.out.println("Ma tran vua tao:");
			String[][] s = new String[n][n];
			taoMaTranVuong(s, a);
			for(int i = 0; i < s.length; i++)
			{
				for(int j = 0; j < s[i].length; j++)
					System.out.print(s[i][j] + " ");
				System.out.println();
			}	
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}
	}
	public static void taoMangNgauNhienMotChieu(int[] a, int n) {
		Random random = new Random();
		for(int i = 0 ; i < a.length; i++)
			a[i] = random.nextInt(n);
	}
	public static void taoMaTranVuong(String[][] s, int[] a) {
		for(int i = 0; i < s.length; i++)
		{
			for(int j = 0; j < s[i].length; j++)
			{
				s[i][a[i]] = "Q";
				if(s[i][j] == null)
					s[i][j] = "*";
			}
		}
	}
}
