package BigExerciseDay1_TranPhamHaiDang;

import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

public class bai2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			int[][] a = new int[n][n];
			
			System.out.println("Nhap cac phan tu cho ma tran vuong:");
			for(int i = 0; i < a.length; i++)
			{
				for(int j = 0; j < a[i].length; j++)
				{
					System.out.println("a[" + i + "][" + j + "] = ");
					a[i][j] = sc.nextInt();
				}
			}
			
			System.out.println("Ma tran vuong vua nhap:");
			for(int i = 0; i < a.length; i++)
			{
				for(int j = 0; j < a[i].length; j++)
					System.out.print(a[i][j] + " ");
				System.out.println();
			}	
			
			System.out.println("Phan tu lon nhat va nho nhat cua moi dong:");
			int[][] kq1 = new int[n][2];
			timPhanTuLonNhat_NhoNhat_MoiDong(a, kq1);
			for(int i = 0; i < kq1.length; i++)
			{
				System.out.println("Phan tu lon nhat cua dong " + i + ": " + kq1[i][0]);
				System.out.println("Phan tu nho nhat cua dong " + i + ": " + kq1[i][1]);
			}
			System.out.println("Nhap x:");
			int x = sc.nextInt();
			thayDoiDuongCheoChinh_DuongCheoPhu(a, x);
			System.out.println("Ma tran vuong sau khi nhap x:");
			for(int i = 0; i < a.length; i++)
			{
				for(int j = 0; j < a[i].length; j++)
					System.out.print(a[i][j] + " ");
				System.out.println();
			}	
			
			System.out.println("Phan tu am on nhat va phan tu duong nho nhat trong ma tran vuong:");
			int[] kq2 = new int[2];
			boolean[] kq3 = new boolean[2];
			timPhanTuAmLonNhat_NhoNhat(a, kq2, kq3);
			if(kq3[0] == false)
				System.out.println("Ma tran vuong khong co phan tu am");
			else
				System.out.println("Phan tu am lon nhat: " + kq2[0]);
			if(kq3[1] == false)
				System.out.println("Ma tran vuong khong co phan tu duong");
			else
				System.out.println("Phan tu duong nho nhat: " + kq2[1]);
			
			System.out.println("So phan tu duong nam o tam giac phia tren duong cheo chinh: " 
					+ demPhanTuDuong_TamGiacPhiaTrenDuongCheoChinh(a));
			System.out.println("So phan tu am chia het cho 2 va chia het cho 3: " 
					+ demSoAmChiaHetCho2_Cho3(a));
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}	
	}
	public static void timPhanTuLonNhat_NhoNhat_MoiDong(int[][] a, int[][] kq1) {	
		int max = 0;
		int min = 0;
		for(int i = 0; i < a.length; i++)
		{
			max = a[i][0];
			min = a[i][0];
			for(int j = 0; j < a[i].length; j++)
			{
				if(a[i][j] > max)
					max = a[i][j];
				if(a[i][j] < min)
					min = a[i][j];
			}
			kq1[i][0] = max;
			kq1[i][1] = min;	
		}
	}
	public static void thayDoiDuongCheoChinh_DuongCheoPhu(int[][] a, int x) {
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				if(i == j || i + j == a.length - 1)
					a[i][j] = x;
			}
		}
	}
	public static void timPhanTuAmLonNhat_NhoNhat(int[][] a, int[] kq2, boolean[] kq3) {
		int max_am = -1;
		int min_duong = 1;
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				if(kq3[0] == true && kq3[1] == true)
					break;
				if(a[i][j] < 0)
				{
					max_am = a[i][j];
					kq3[0] = true;
				}
				if(a[i][j] > 0)
				{
					min_duong = a[i][j];
					kq3[1] = true;
				}
			}		
		}
		if(kq3[0] == true && kq3[1] == true)
		{
			for(int i = 0; i < a.length; i++)
			{
				for(int j = 0; j < a[i].length; j++)
				{
					if(a[i][j] < 0 && a[i][j] > max_am)
					{
						max_am = a[i][j];
						kq2[0] = a[i][j];
					}
					if(a[i][j] > 0 && a[i][j] < min_duong)
					{
						min_duong = a[i][j];
						kq2[1] = a[i][j];
					}
				}		
			}
		}
	}
	public static int demPhanTuDuong_TamGiacPhiaTrenDuongCheoChinh(int[][] a) {
		int dem = 0;
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				if(i <= j && a[i][j] > 0)
					dem++;
			}
		}
		return dem;
	}
	public static int demSoAmChiaHetCho2_Cho3(int[][] a) {
		int dem = 0;
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				if(a[i][j] < 0 && a[i][j] % 2 == 0 && a[i][j] % 3 == 0)
					dem++;
			}
		}
		return dem;
	}
}
