package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhTienLai {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Lãi suất 1 năm:");
		double laiSuatNam = sc.nextDouble();
		System.out.println("Số tiền gửi:");
		double soTienGui = sc.nextDouble();
		System.out.println("Số tháng:");
		int soThang = sc.nextInt();
		double tienLai = (soTienGui * soThang) * (laiSuatNam / 100 / 12);
		double tongSoTien = soTienGui + tienLai;
		System.out.println("Tiền lãi: " + String.format("%.1f", tienLai) + "\n" + "Tổng vốn và lãi: " + String.format("%.1f", tongSoTien));
	}

}
