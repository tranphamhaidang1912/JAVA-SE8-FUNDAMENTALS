package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhThucLinh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Số sản phẩm:");
		int soSanPham = sc.nextInt();
		System.out.println("Tiền công một sản phẩm");
		double tienCong1SP = sc.nextDouble();
		System.out.println("Tiền thưởng:");
		double tienThuong = sc.nextDouble();
		System.out.println("Số con:");
		int soCon = sc.nextInt();
		double tienLuong = soSanPham * tienCong1SP;
		double phuCap = soCon * 200000;
		double thucLinh = tienLuong + tienThuong + phuCap;
		System.out.println("Tiền lương: " + String.format("%.2f", tienLuong) + "\nPhụ cấp: " + String.format("%.2f", phuCap) + "\nThực lĩnh: " + String.format("%.2f", thucLinh));
	}

}
