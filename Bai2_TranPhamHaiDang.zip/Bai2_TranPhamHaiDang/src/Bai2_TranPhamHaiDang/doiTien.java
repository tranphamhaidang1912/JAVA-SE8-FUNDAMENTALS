package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class doiTien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Tên ngoại tệ:");
		String tenNgoaiTe = sc.nextLine();
		System.out.println("Tỷ giá:");
		double tyGia = sc.nextDouble();
		System.out.println("Số ngoại tệ:");
		int soNgoaiTe = sc.nextInt();
		double thanhTien = tyGia * soNgoaiTe;
		System.out.println("Bạn đang đổi từ: " + tenNgoaiTe + " sang VNĐ\n" + thanhTien);
	}

}
