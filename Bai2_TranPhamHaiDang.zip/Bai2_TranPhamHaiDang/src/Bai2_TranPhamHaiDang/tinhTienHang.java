package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhTienHang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập số lượng:");
		int soLuong = sc.nextInt();
		System.out.println("Nhập đơn giá");
		int donGia = sc.nextInt();
		double thanhTien = soLuong * donGia;
		System.out.println("Thành tiền = " + String.format("%.2f", thanhTien));
	}

}
