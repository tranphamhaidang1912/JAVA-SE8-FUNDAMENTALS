package Bai10_TranPhamHaiDang;

import java.util.Random;
import java.util.Scanner;

enum chosing {
	SCISSOR, PAPER, STONE;	
}

public class playOneTwoThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		String nguoi = "s";
		int computer;
		chosing playermove = null;
		chosing computermove = null;
		boolean trangThaiChoi = false;
		int playtimes = 0;
		int playermark = 0;
		int computermark = 0;
		while(true)
		{
			System.out.println("Nguoi choi chon: ");
			nguoi = sc.nextLine();
			if(nguoi.equalsIgnoreCase("q"))
			{
				System.out.println("Tro choi ket thuc");
				break;
			}				
			
			if(nguoi.equalsIgnoreCase("s"))
				playermove = chosing.SCISSOR;
			else if(nguoi.equalsIgnoreCase("p"))
				playermove = chosing.PAPER;
			else if(nguoi.equalsIgnoreCase("t"))
				playermove = chosing.STONE;
			
			computer = rand.nextInt(3);
			if(computer == 0)
				computermove = chosing.SCISSOR;
			else if(computer == 1)
				computermove = chosing.PAPER;
			else computermove = chosing.STONE;
			++playtimes;
			System.out.println("May chon: " + computermove);
						
			if(ktKetQua(playermove, computermove) == 1)
			{
				System.out.println("Chuc mung ban da thang");
				playermark++;
			}
			else if(ktKetQua(playermove, computermove) == 0)
				System.out.println("Ngang tai ngang suc");
			else 
			{
				System.out.println("Oh oh, ban thua roi");
				computermark++;
			}
			
			if(playermark == 5)
			{
				System.out.println("So lan choi: " + playtimes);
				System.out.println("Diem nguoi choi: " + playermark);
				System.out.println("Diem may: " + computermark);
				System.out.println("Ban la nguoi thang cuoc!");
				break;
			}
			if(computermark == 5)
			{
				System.out.println("So lan choi: " + playtimes);
				System.out.println("Diem nguoi choi: " + playermark);
				System.out.println("Diem may: " + computermark);
				System.out.println("Ban la nguoi thua cuoc!");
				break;
			}
		}	
	}
	public static int ktKetQua(chosing playermove, chosing computermove) {
		if(playermove == chosing.SCISSOR)
		{
			if(computermove == chosing.PAPER)
				return 1;
			else if(computermove == chosing.STONE)
				return -1;
		}
		if(playermove == chosing.PAPER)
		{
			if(computermove == chosing.STONE)
				return 1;
			else if(computermove == chosing.SCISSOR)
				return -1;
		}
		if(playermove == chosing.STONE)
		{
			if(computermove == chosing.SCISSOR)
				return 1;
			else if(computermove == chosing.PAPER)
				return -1;
		}
		return 0;
	}
}
