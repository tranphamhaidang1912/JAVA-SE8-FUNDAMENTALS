package Bai10_TranPhamHaiDang;

enum DenGiaoThong {
	XANH(30) {
		@Override
		public DenGiaoThong chuyenDen() {
			return VANG;
		}
	}, VANG(10) {
		@Override
		public DenGiaoThong chuyenDen() {
			return DO;
		}
	}, DO(30){
		@Override
		public DenGiaoThong chuyenDen() {
			return XANH;
		}
	};
	private final int soGiay;
	private DenGiaoThong(int soGiay) {
		this.soGiay = soGiay;
	}
	public int getSoGiay() {
		return soGiay;
	}
	public abstract DenGiaoThong chuyenDen();
}

public class hienThiDenGiaoThong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		System.out.println(DenGiaoThong.XANH.getSoGiay());
		System.out.println(DenGiaoThong.XANH.chuyenDen());
		System.out.println(DenGiaoThong.VANG.getSoGiay());
		System.out.println(DenGiaoThong.VANG.chuyenDen());
		System.out.println(DenGiaoThong.DO.getSoGiay());
		System.out.println(DenGiaoThong.DO.chuyenDen());
	}
}
