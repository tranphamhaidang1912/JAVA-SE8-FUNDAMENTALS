package Bai10_TranPhamHaiDang;

import java.lang.invoke.SwitchPoint;

enum PhepToan  {
	CONG, TRU, NHAN, CHIA;
	
	public double tinhToan(double soThuNhat, double soThuHai) {
		switch (this) {
		case CONG:
			return soThuNhat + soThuHai;
		case TRU:
			return soThuNhat - soThuHai;
		case NHAN:
			return soThuNhat * soThuHai;
		case CHIA:
			return soThuNhat / soThuHai;
		default:
			throw new AssertionError("Khong tim thay phep toan: " + this);
		}
	}
}

public class tinhTongHieuTichThuong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(PhepToan.CONG.tinhToan(1, 2));
		System.out.println(PhepToan.TRU.tinhToan(3, 4));
		System.out.println(PhepToan.NHAN.tinhToan(5, 6));
		System.out.println(PhepToan.CHIA.tinhToan(7, 8));
	}

}
