package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhSvaPHinhTron {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		final double PI = 3.14;
		System.out.println("Nhập bán kính:");
		double r = sc.nextDouble();
		double chuVi = 2 * r * PI;
		double dienTich = r * r * PI;
		System.out.println("Chu vi: " + String.format("%.2f", chuVi) + "\n" + "Diện tích: " + String.format("%.2f", dienTich));
	}

}
