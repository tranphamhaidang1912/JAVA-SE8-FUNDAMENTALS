package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhRHinhTron {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		final double PI = 3.14;
		System.out.println("Nhập diện tích:");
		double dienTich = sc.nextDouble();
		double r = Math.sqrt(dienTich / PI);
		System.out.println("Bán kính = " + String.format("%.2f", r));
	}

}
