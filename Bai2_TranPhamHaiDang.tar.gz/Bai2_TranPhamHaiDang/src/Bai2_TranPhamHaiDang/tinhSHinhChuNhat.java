package Bai2_TranPhamHaiDang;

import java.util.Scanner;

public class tinhSHinhChuNhat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Chu vi:");
		double chuVi = sc.nextDouble();
		double chieuRong = chuVi / 5;
		double chieuDai = 1.5 * chieuRong;
		double dienTich = chieuDai * chieuRong;
		System.out.println("Diện tích = " + String.format("%.2f", dienTich));
	}

}
