package Bai13_TranPhamHaiDang;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Scanner;

public class thongBaoNgaySinhNhat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Calendar cal = Calendar.getInstance();
		System.out.println("Ngay thang nam hom nay: " + dateFormat.format(cal.getTime()));
		System.out.println("Nhap ngay thang nam sinh: ");
		String ngaySinh = sc.nextLine();
		String[] namSinh = ngaySinh.split("/");
		LocalDate toDay = LocalDate.now();
		LocalDate birthDay = LocalDate.of(toDay.getYear(), Integer.parseInt(namSinh[1]), Integer.parseInt(namSinh[0]));
		Period period = Period.between(toDay, birthDay);
		if(period.getDays() == 0 && period.getMonths() == 0)
			System.out.println("Happy birthday to you");
		else if(period.getMonths() > 0 || period.getMonths() == 0 && period.getDays() > 0)
			System.out.println("Please wait...");
		else if(period.getDays() < 0)
			System.out.println("See you next birthday");
	}

}
