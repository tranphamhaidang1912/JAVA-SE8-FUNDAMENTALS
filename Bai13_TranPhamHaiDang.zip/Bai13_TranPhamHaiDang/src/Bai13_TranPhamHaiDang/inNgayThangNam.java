package Bai13_TranPhamHaiDang;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class inNgayThangNam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");;
		Calendar cal = Calendar.getInstance();
		System.out.println("Ngay thang nam hien tai: " + dateFormat.format(cal.getTime()) 
							+ " , la ngay thu " + cal.get(Calendar.DAY_OF_WEEK) + " trong tuan"
							+ ", la tuan thu " + cal.get(Calendar.WEEK_OF_YEAR) + " trong nam");
		cal.add(Calendar.WEEK_OF_YEAR, 1);
		System.out.println("Mot tuan sau se la: " + dateFormat.format(cal.getTime()));
	}
}
