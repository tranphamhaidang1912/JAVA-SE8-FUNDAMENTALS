package Bai6_TranPhamHaiDang;

import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

public class xuLyMangHaiChieu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap so dong n:");
		int n = sc.nextInt();
		System.out.println("Nhap so cot m:");
		int m = sc.nextInt();
		int[][] a = new int[n][m];
		System.out.println("Nhap gia tri cho cac phan tu trong mang");
		for(int i = 0; i < a.length; i++)
			for(int j = 0; j < a[i].length; j++)
				a[i][j] = sc.nextInt();
		System.out.println("Mang da nhap:");
		int demChan = 0;
		int demLe = 0;
		double tongChan = 0;
		double tongLe = 0;
		int viTriDongPhanTuLonNhat = 0;
		int viTriCotPhanTuLonNhat = 0;
		int viTriDongPhanTuNhoNhat = 0;
		int viTriCotPhanTuNhoNhat = 0;
		int max = a[0][0];
		int min = a[0][0];
		int[] temp = new int[n * m];
		int z = 0;
		int[] tanSuatXuatHien = new int[n * m];
		boolean ktXuatHien = false;
		boolean ktPhanTuAm = false;
		for(int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
			{
				System.out.print(a[i][j] + " ");
				if(a[i][j] % 2 == 0)
				{
					++demChan;
					tongChan += a[i][j];
				}
				else
				{
					++demLe;
					tongLe += a[i][j];
				}
				if(a[i][j] > max)
					max = a[i][j];					
				if(a[i][j] < min)
					min = a[i][j];				
				for(int k = 0; k < z; k++)
				{
					if(a[i][j] == temp[k])
					{
						tanSuatXuatHien[k]++;
						ktXuatHien = true;
					}
				}
				if(ktXuatHien == false)
				{
					temp[z] = a[i][j];
					z++;
				}
				else ktXuatHien = false;
				if(ktPhanTuAm == false && a[i][j] < 0)
					ktPhanTuAm = true;					
			}	
			System.out.println();
		}							
		System.out.println("So phan tu chan trong mang: " + demChan);
		System.out.println("So phan tu le trong mang: " + demLe);
		System.out.println("Gia tri trung binh cac phan tu chan trong mang: " + tongChan / demChan);
		System.out.println("Gia tri trung binh cac phan tu le trong mang: " + tongLe / demLe);
		System.out.print("Phan tu lon nhat trong mang: " + max);
		for(int i = 0; i < a.length; i++)
			for(int j = 0; j < a[i].length; j++)
				if(a[i][j] == max)
					System.out.print(" (dong " + i + ", cot " + j + ")");
		System.out.println();
		System.out.print("Phan tu nho nhat trong mang: " + min);
		for(int i = 0; i < a.length; i++)
			for(int j = 0; j < a[i].length; j++)
				if(a[i][j] == min)
					System.out.print(" (dong " + i + ", cot " + j + ")");
		System.out.println();
		System.out.println("Cac phan tu co so lan xuat hien nhieu nhat trong mang: ");
		int tanSuatXuatHienNhieuNhat = 0;
		for(int k = 0; k < z; k++)
		{
			if(tanSuatXuatHien[k] > tanSuatXuatHienNhieuNhat)
				tanSuatXuatHienNhieuNhat = tanSuatXuatHien[k];
		}
		for(int k = 0; k < z; k++)
		{
			if(tanSuatXuatHien[k] == tanSuatXuatHienNhieuNhat)
			{
				System.out.print(temp[k]);
				for(int i = 0; i < a.length; i++)
					for(int j = 0; j < a[i].length; j++)
						if(a[i][j] == temp[k])
							System.out.print(" (dong " + i + ", cot " + j + ")");
				System.out.println();
			}		
		}
		if(ktPhanTuAm == true)
			System.out.println("Ma tran nay co phan tu am");
		else
			System.out.println("Ma tran nay khong co phan tu am");
	}
}
