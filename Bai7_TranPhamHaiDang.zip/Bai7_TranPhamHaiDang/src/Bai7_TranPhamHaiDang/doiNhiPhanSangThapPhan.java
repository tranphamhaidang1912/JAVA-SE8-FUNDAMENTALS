package Bai7_TranPhamHaiDang;

import java.util.Scanner;

public class doiNhiPhanSangThapPhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		int soThapPhan = 0;
		for(int soMu = 0; n != 0; soMu++)
		{
			if(n % 10 == 1)
				soThapPhan += tinhLuyThua(2, soMu);
			n /= 10;	
		}
		System.out.println(soThapPhan);
	}
	public static int tinhLuyThua(int x, int n) {
		
		int S = 1;
		for(int i = 1; i <= n; i++)
			S *= x;
		return S;
	}
}
