package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class ktSoNT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			
			if(ktSNT(n) == true) 
				System.out.println(n + " La so NT");
			else
				System.out.println(n + " Khong la so NT");
		} catch (IndexOutOfBoundsException | ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}
		
	}
	public static boolean ktSNT(int n) {
		if(n < 2) return false;
		for(int i = 2; i <= Math.sqrt(n); i++)
			if(n % i == 0)
				return false;
		return true;
	}
}
