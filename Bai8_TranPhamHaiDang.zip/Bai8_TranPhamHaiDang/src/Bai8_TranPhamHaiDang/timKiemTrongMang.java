package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class timKiemTrongMang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap n");
			int n = sc.nextInt();
			int[] a = new int[n];
			System.out.println("Nhap gia tri cho cac phan tu trong mang");
			for(int i = 0; i < a.length; i++)
				a[i] = sc.nextInt();
			System.out.println("Nhap x:");
			int x = sc.nextInt();
			timKiemTrongMang(a, n, x);
		} catch (ArrayIndexOutOfBoundsException | ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static void timKiemTrongMang(int[] a, int n, int x) {
		
		System.out.println("Mang da nhap:");
		boolean flag = false;
		int[] temp = new int[n];
		int j = 0;
		for(int i = 0; i < a.length; i++)
		{
			System.out.print(a[i] + " ");
			if(flag == false && a[i] == x)
				flag = true;
			if(a[i] > x)
			{
				temp[j] = a[i];
				j++;
			}
		}	
		System.out.println();
		if(flag == true)
		{
			System.out.print(x + " xuat hien trong mang tai cac vi tri: ");
			for(int i = 0; i < a.length ; i++)
				if(a[i] == x)
					System.out.print(i + " ");
			System.out.println();
		}			
		else System.out.println(x + " khong xuat hien trong mang");
		if(j > 0)
		{
			System.out.println(x + " khong lon hon tat ca cac so trong mang");
			System.out.println("Tat ca cac so lon hon " + x + " la:");
			for(int i = 0; i < j; i++)
				System.out.print(temp[i] + " ");
		}
		else System.out.println(x + " lon hon tat ca cac so trong mang");
	}
}
