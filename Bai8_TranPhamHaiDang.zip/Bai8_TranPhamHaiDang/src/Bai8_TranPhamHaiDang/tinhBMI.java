package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class tinhBMI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap chieu cao:");
			double chieuCao = sc.nextDouble();
			System.out.println("Nhap can nang:");
			double canNang = sc.nextDouble();
			double BMI = tinhBMI(chieuCao, canNang);
			System.out.println("BMI = " + BMI + " - Ket luan: " + danhGiaBMI(BMI));
		} catch (ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static double tinhBMI(double chieuCao, double canNang) {
		return canNang / (chieuCao * chieuCao);
	}
	public static String danhGiaBMI(double BMI) {
		if(BMI < 18.5)
			return "Ban gay";
		else if(BMI < 24.99)
			return "Ban binh thuong";
		else return "Ban thua can";
	}
}
