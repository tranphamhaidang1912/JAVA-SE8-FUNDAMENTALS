package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class tinhA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap n:");
			int n = sc.nextInt();
			System.out.println("Nhap x:");
			double x = sc.nextDouble();				
			System.out.println("A = (x * x + x + 1) mu n + (x * x - x + 1) mu n = " + tinhBT(x, n));
		} catch (IndexOutOfBoundsException | ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}	
	}
	public static double tinhLuyThua(double x, int n) {
		
		double S = 1;
		for(int i = 1; i <= n; i++)
			S *= x;
		return S;
	}
	public static double  tinhBT(double x, int n) {
		double s1 = (x * x + x + 1);
		double s2 = (x * x - x + 1);
		double A = tinhLuyThua(s1, n) + tinhLuyThua(s2, n);
		return A;
	}
}
