package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class kiemTraMangMotChieu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap n");
			int n = sc.nextInt();
			int[] a = new int[n];
			System.out.println("Nhap gia tri cho cac phan tu trong mang");
			for(int i = 0; i < a.length; i++)
				a[i] = sc.nextInt();
			ktMangMotChieu(a);
		} catch (ArrayIndexOutOfBoundsException | ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static void ktMangMotChieu(int[] a) {
		
		boolean tangDan = true;
		boolean giamDan = true;
		int indexFirst = -1;
		System.out.println("Mang da nhap:");
		for(int i = 0; i < a.length; i++)
		{
			System.out.print(a[i] + " ");
			if(i != (a.length - 1))
			{
				if(tangDan == true && a[i] > a[i+1])
					tangDan = false;
				if(giamDan == true && a[i] < a[i+1])
					giamDan = false;
			}
			if(indexFirst == -1 && a[i] % 10 == 6)
				indexFirst = i;
		}
		System.out.println();
		if(tangDan == true)
			System.out.println("Mang da duoc sap theo thu tu tang dan");
		else System.out.println("Mang chua duoc sap theo thu tang dan");
		if(giamDan == true)
			System.out.println("Mang da duoc sap theo thu tu giam dan");
		else System.out.println("Mang chua duoc sap theo thu giam dan");
		if(indexFirst != -1)
			System.out.println("Phan tu dau tien trong mang co tan cung la 6: " + a[indexFirst]);
		else System.out.println("Khong co phan tu nao trong mang co tan cung la 6");
	}
}
