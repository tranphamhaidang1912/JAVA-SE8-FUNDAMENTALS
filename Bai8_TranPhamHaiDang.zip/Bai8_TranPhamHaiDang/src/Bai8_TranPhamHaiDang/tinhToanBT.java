package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class tinhToanBT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap x:");
			int x = sc.nextInt();
			System.out.println("Nhap y:");
			int y = sc.nextInt();
			System.out.println(tinhGTBT(x, y));			
		} catch (ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static double tinhGTBT(int x, int y) {
		int tu = 5 * x - y;
		int mau = 2 * x + 7 * y;
		return Math.sqrt((double)tu / mau);
	}
}
