package Bai8_TranPhamHaiDang;

import java.util.Scanner;

public class timCapSoMangMotChieu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap n");
			int n = sc.nextInt();
			int[] a = new int[n];
			System.out.println("Nhap gia tri cho cac phan tu trong mang");
			for(int i = 0; i < a.length; i++)
				a[i] = sc.nextInt();
			timCapSoMangMotChieu(a);
		} catch (ArrayIndexOutOfBoundsException | ArithmeticException | IllegalArgumentException | NullPointerException e) {
			// TODO: handle exception
			System.out.println("Loi: " + e.toString());
		}		
	}
	public static void timCapSoMangMotChieu(int[] a) {
		
		System.out.println("Mang da nhap");
		for(int value : a)
			System.out.print(value + " ");
		System.out.println("\nCac cap so co quan he chia het:");
		for(int i = 0; i < a.length; i++)
		{
			for(int j = i + 1; j < a.length; j++)
				if(a[i] % a[j] == 0 || a[j] % a[i] == 0)
					System.out.println(a[i] + " & " + a[j]);
		}
		System.out.println("Cac cap so co quan he so nay gap 2 lan so kia:");
		for(int i = 0; i < a.length; i++)
		{
			for(int j = i + 1; j < a.length; j++)
				if(a[i] == 2 * a[j]|| a[j] == 2 * a[i])
					System.out.println(a[i] + " & " + a[j]);
		}
		System.out.println("Cac cap so co quan he tong 2 so bang 8:");
		for(int i = 0; i < a.length; i++)
		{
			for(int j = i + 1; j < a.length; j++)
				if(a[i] + a[j] == 8)
					System.out.println(a[i] + " & " + a[j]);
		}
	}
}
