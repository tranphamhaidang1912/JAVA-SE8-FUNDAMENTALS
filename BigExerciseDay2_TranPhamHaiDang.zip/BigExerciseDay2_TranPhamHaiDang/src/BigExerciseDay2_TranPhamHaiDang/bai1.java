package BigExerciseDay2_TranPhamHaiDang;

import java.util.Scanner;

public class bai1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhập trọng lượng bưu phẩm (gram):");
			int trongLuongBuuPham = sc.nextInt();
			System.out.println("Chọn hình thức gửi:");
			System.out.println("1/Hình thức 1\n2/Hình thức 2\n3/Hình thức 3");
			int hinhThucGui = sc.nextInt();
			System.out.println("Chọn EMS:");
			System.out.println("1/Nội tỉnh\n2/Liên tỉnh");
			int EMS = sc.nextInt();
			int vung = 0;
			int tuyen = 0;
			if(EMS == 2)
			{
				System.out.println("Chọn vùng:");
				if(hinhThucGui != 2)
				{
					System.out.println("1/Vùng 1\n2/Vùng 2\n3/Vùng 3");
					vung = sc.nextInt();
					if(vung == 2)
					{
						System.out.println("Chọn tuyến:");
						System.out.println("1/Đà Nẵng đi Hà Nội, TP.HCM và ngược lại\n2/Hà Nội đi TP.HCM và ngược lại");
						tuyen = sc.nextInt();
					}
				}
				else
				{
					System.out.println("1/Vùng 1\n2/Vùng 2");
					vung = sc.nextInt();
					if(vung == 2)
					{
						System.out.println("Chọn tuyến:");
						System.out.println("1/Đà Nẵng đi Hà Nội, TP.HCM và ngược lại\n2/Hà Nội đi TP.HCM và ngược lại");
						tuyen = sc.nextInt();
					}
				}
			}
			double cuocEMS = tinhCuocEMS(trongLuongBuuPham, hinhThucGui, EMS, vung, tuyen);
			System.out.println(cuocEMS);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}	
	}
	public static double tinhCuocEMS(int trongLuongBuuPham, int hinhThucGui, int EMS, int vung, int tuyen) {
		double cuocEMS = 0;
		int soLan = 0;
		switch (hinhThucGui) {
		case 1:
			switch (EMS) {
			case 1:
				if(trongLuongBuuPham <= 100)
					return cuocEMS = 8000;
				else if(trongLuongBuuPham <= 250)
					return cuocEMS = 10000;
				else if(trongLuongBuuPham <= 500)
					return cuocEMS = 12500;
				else if(trongLuongBuuPham <= 1000)
					return cuocEMS = 15000;
				else if(trongLuongBuuPham <= 1500)
					return cuocEMS = 18000;
				else if(trongLuongBuuPham <= 2000)
					return cuocEMS = 21000;
				else
				{
					soLan = soLan(trongLuongBuuPham);
					return cuocEMS = 21000 + soLan * 1600;
				}					
			case 2:
				switch (vung) {
				case 1:
					if(trongLuongBuuPham <= 50)
						return cuocEMS = 8500;
					else if(trongLuongBuuPham <= 100)
						return cuocEMS = 12500;
					else if(trongLuongBuuPham <= 250)
						return cuocEMS = 16500;
					else if(trongLuongBuuPham <= 500)
						return cuocEMS = 23500;
					else if(trongLuongBuuPham <= 1000)
						return cuocEMS = 33000;
					else if(trongLuongBuuPham <= 1500)
						return cuocEMS = 40000;
					else if(trongLuongBuuPham <= 2000)
						return cuocEMS = 48500;
					else
					{
						soLan = soLan(trongLuongBuuPham);
						return cuocEMS = 48500 + soLan * 3800;
					}					
				case 2:
					switch (tuyen) {
					case 1:
						if(trongLuongBuuPham <= 50)
							return cuocEMS = 9500;
						else if(trongLuongBuuPham <= 100)
							return cuocEMS = 13500;
						else if(trongLuongBuuPham <= 250)
							return cuocEMS = 20000;
						else if(trongLuongBuuPham <= 500)
							return cuocEMS = 26500;
						else if(trongLuongBuuPham <= 1000)
							return cuocEMS = 38500;
						else if(trongLuongBuuPham <= 1500)
							return cuocEMS = 49500;
						else if(trongLuongBuuPham <= 2000)
							return cuocEMS = 59500;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 59500 + soLan * 8500;
						}					
					case 2:
						if(trongLuongBuuPham <= 50)
							return cuocEMS = 9500;
						else if(trongLuongBuuPham <= 100)
							return cuocEMS = 13500;
						else if(trongLuongBuuPham <= 250)
							return cuocEMS = 21500;
						else if(trongLuongBuuPham <= 500)
							return cuocEMS = 28000;
						else if(trongLuongBuuPham <= 1000)
							return cuocEMS = 40500;
						else if(trongLuongBuuPham <= 1500)
							return cuocEMS = 52500;
						else if(trongLuongBuuPham <= 2000)
							return cuocEMS = 63500;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 63500 + soLan * 8500;
						}						
					default:
						break;
					}	
				case 3:
					if(trongLuongBuuPham <= 50)
						return cuocEMS = 10000;
					else if(trongLuongBuuPham <= 100)
						return cuocEMS = 14000;
					else if(trongLuongBuuPham <= 250)
						return cuocEMS = 22500;
					else if(trongLuongBuuPham <= 500)
						return cuocEMS = 29500;
					else if(trongLuongBuuPham <= 1000)
						return cuocEMS = 43500;
					else if(trongLuongBuuPham <= 1500)
						return cuocEMS = 55500;
					else if(trongLuongBuuPham <= 2000)
						return cuocEMS = 67500;
					else
					{
						soLan = soLan(trongLuongBuuPham);
						return cuocEMS = 67500 + soLan * 9500;
					}			
				default:
					break;
				}
				break;
			default:
				break;
			}
			break;
		case 2:
			switch (EMS) {
			case 1:
				if(trongLuongBuuPham <= 2000)
					return cuocEMS = 50000;
				else
				{
					soLan = soLan(trongLuongBuuPham);
					return cuocEMS = 50000 + soLan * 5000;
				}
					
			case 2:
				switch (vung) {
				case 1:
					if(trongLuongBuuPham <= 2000)
						return cuocEMS = 70000;
					else
					{
						soLan = soLan(trongLuongBuuPham);
						return cuocEMS = 70000 + soLan * 7000;
					}						
				case 2:
					switch (tuyen) {
					case 1:
						if(trongLuongBuuPham <= 2000)
							return cuocEMS = 110000;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 110000 + soLan * 12000;
						}					
					case 2:
						if(trongLuongBuuPham <= 2000)
							return cuocEMS = 130000;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 130000 + soLan * 20000;
						}					
					default:
						break;
					}
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
			break;
		case 3:
			switch (EMS) {
			case 1:		
				if(trongLuongBuuPham <= 2000)
					return cuocEMS = 50000;
				else
				{
					soLan = soLan(trongLuongBuuPham);
					return cuocEMS = 50000 + soLan * 5000;
				}
					
			case 2:		
				switch (vung) {
				case 1:			
					if(trongLuongBuuPham <= 2000)
						return cuocEMS = 70000;
					else
					{
						soLan = soLan(trongLuongBuuPham);
						return cuocEMS = 70000 + soLan * 7000;
					}			
				case 2:		
					switch (tuyen) {
					case 1:		
						if(trongLuongBuuPham <= 2000)
							return cuocEMS = 85000;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 85000 + soLan * 10000;
						}						
					case 2:
						if(trongLuongBuuPham <= 2000)
							return cuocEMS = 100000;
						else
						{
							soLan = soLan(trongLuongBuuPham);
							return cuocEMS = 100000 + soLan * 12000;
						}						
					default:
						break;
					}
					break;
				case 3:			
					if(trongLuongBuuPham <= 2000)
						return cuocEMS = 110000;
					else
					{
						soLan = soLan(trongLuongBuuPham);
						return cuocEMS = 110000 + soLan * 15000;
					}
						
				default:
					break;
				}
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		return cuocEMS;
	}
	public static int soLan(int trongLuongBuuPham) {
		int soDu = trongLuongBuuPham - 2000;
		int soLan = 0;
		if(soDu % 500 != 0)
		{
			soLan = soDu / 500;
			soLan++;
		}
		else soLan = soDu / 500;
		return soLan;
	}
}
