package BigExerciseDay2_TranPhamHaiDang;

import java.util.Scanner;

public class bai2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhập số m3 nước đã dùng trong tháng:");
			double soNuocDaDung = sc.nextDouble();
			System.out.println("Chọn đối tượng:");
			System.out.println("1/Sinh hoạt\n2/Không sinh hoạt");
			int doiTuong = sc.nextInt();
			double tienNuoc = tinhTienNuoc(soNuocDaDung, doiTuong);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}	
	}
	public static double tinhTienNuoc(double soNuocDaDung, int doiTuong) {
		Scanner sc = new Scanner(System.in);
		double tienNuoc = 0;
		double tienNuocKhongThue = 0;
		double tienThueGTGT = 0;
		double phiBaoVeMoiTruong = 0;
		switch (doiTuong) {
		case 1:
			System.out.println("Nhập số người trong hộ gia đình:");
			int soNguoi = sc.nextInt();
			double soNuocMotNguoiDung = soNuocDaDung / soNguoi;
			if(soNuocDaDung <= 4)
				tienNuocKhongThue = soNguoi * soNuocMotNguoiDung * 5300;
			else if(soNuocDaDung <= 6)
				tienNuocKhongThue = soNguoi * (4 * 5300 + (soNuocMotNguoiDung - 4) * 10200);
			else
				tienNuocKhongThue = soNguoi * (4 * 5300 + 2 * 10200 + (soNuocMotNguoiDung  - 6) * 11400);	
			break;
		case 2:		
			System.out.println("Nhập loại:");
			System.out.println("1/Đơn vị sản xuất\n"
					+ "2/Cơ quan, đoàn thể, HC sự nghiệp\n"
					+ "3/Đơn vị kinh doanh, dịch vụ");
			int loai = sc.nextInt();
			switch (loai) {
			case 1:		
				tienNuocKhongThue = soNuocDaDung * 9600;
				break;
			case 2:		
				tienNuocKhongThue = soNuocDaDung * 10300;
				break;
			case 3:		
				tienNuocKhongThue = soNuocDaDung * 16900;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		tienThueGTGT = tienNuocKhongThue * 0.05;
		phiBaoVeMoiTruong = tienNuocKhongThue * 0.1;
		tienNuoc = tienNuocKhongThue + tienThueGTGT + phiBaoVeMoiTruong;
		xuatThongTin(soNuocDaDung, tienNuocKhongThue, tienThueGTGT, phiBaoVeMoiTruong, tienNuoc);
		return tienNuoc;
	}
	public static void xuatThongTin(double soNuocDaDung, double tienNuocKhongThue, double tienThueGTGT, double phiBaoVeMoiTruong, double tienNuoc) {
		System.out.println("Tổng số m3: " + soNuocDaDung);
		System.out.println("Tiền nước không thuế: " + tienNuocKhongThue);
		System.out.println("Tiền thuế GTGT: " + tienThueGTGT);
		System.out.println("Phí bảo vệ môi trường: " + phiBaoVeMoiTruong);
		System.out.println("Số tiền cuối cùng phải trả: " + tienNuoc);
	}
}
