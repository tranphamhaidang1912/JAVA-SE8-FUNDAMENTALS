package BigExerciseDay2_TranPhamHaiDang;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class bai7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			troChoiDoanTu(taoMangTu());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}
	}
	static String[] taoMangTu() {
        String[] mangTu = {"program", "developer", "testing", "coder", "algorithm", "bug", "console", "user", "system", "application"};
        return mangTu;
    }

    static void troChoiDoanTu(String[] mangTu) throws IOException {
    	boolean kt = true;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("CHÀO MỪNG BẠN ĐẾN VỚI TRÒ CHƠI ĐOÁN TỪ:");
        System.out.println("Chúng ta có: " + mangTu.length + " ô chữ cái");
        System.out.println("Bạn muốn đoán ô thứ mấy");
        int viTri = 0;
        while (kt) {
            try {
                viTri = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Bạn vui lòng nhập lại số: " + num.toString());
                continue;
            }
            if (viTri < 0 || viTri > mangTu.length) {
                System.out.println("Bạn vui lòng nhập lại số từ 0 trở lên và không quá " + mangTu.length);
                continue;
            }
            kt = false;
        }
        String chuoi = mangTu[viTri];
        System.out.println("Đây là một từ có " + chuoi.length() + " chữ cái");
        char[] mangTuKhoa = new char[chuoi.length()];
        for (int i = 0; i < mangTuKhoa.length; i++) {
            mangTuKhoa[i] = chuoi.charAt(i);
        }
        char[] hienThi = new char[chuoi.length()];
        for (int i = 0; i < mangTuKhoa.length; i++) {
            hienThi[i] = '*';
            System.out.print(hienThi[i]);
        }
        System.out.println();
        String chuCai = "";

        kt = true;
        boolean thang = false;
        int soLanChoi = 1;
        while (!thang) {
            while (kt) {
                System.out.println("Mời bạn đoán chữ cái thứ " + soLanChoi);
                chuCai = input.readLine();
                if (chuCai.length() > 1) {
                    System.out.println("Bạn vui lòng nhập lại một chữ cái");
                    continue;
                }
                int dem = 0;
                for (int i = 0; i < mangTuKhoa.length; i++) {
                    if (mangTuKhoa[i] == chuCai.charAt(0)) {
                        hienThi[i] = mangTuKhoa[i];
                        dem++;
                    }
                }
                if (dem > 0) {
                    System.out.println("Chúc mừng bạn, có " + dem + " chữ " + chuCai.charAt(0));
                } else {
                    System.out.println("Không có chữ " + chuCai.charAt(0));
                }
                for (int i = 0; i < hienThi.length; i++) {
                    System.out.print(hienThi[i]);
                }
                System.out.println();
                int diem = 0;
                for (int i = 0; i < hienThi.length; i++) {
                    if(hienThi[i] == mangTuKhoa[i]){
                        diem++;
                    }
                }
                if(diem == mangTuKhoa.length)
                {
                    kt = false;
                    thang=true;
                }
                soLanChoi++;
            }
        }
        if(thang){
            System.out.println("CHÚC MỪNG! BẠN ĐÃ THẮNG!");
        }
    }
}
