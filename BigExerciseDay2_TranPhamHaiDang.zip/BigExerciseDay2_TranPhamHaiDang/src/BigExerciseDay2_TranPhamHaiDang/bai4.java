package BigExerciseDay2_TranPhamHaiDang;

import java.util.Scanner;

public class bai4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter the number of students: ");
			int n = sc.nextInt();
			double[] kq = nhapDiemSinhVien(n);
			System.out.println("The average is: " + kq[0] / n);
			System.out.println("The maximum is: " + kq[1]);
			System.out.println("The minimum is: " + kq[2]);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}	
	}
	public static double[] nhapDiemSinhVien(int n) {
		Scanner sc = new Scanner(System.in);
		int i = 1;
		double[] kq = new double[3];
		double grade = 0;
		do {
			System.out.print("Enter the grade for student " + i + ": ");
			grade = sc.nextDouble();
			if(grade < 0 || grade > 10)
			{
				System.out.println("Invalid grade, try again...");
				continue;
			}
			kq[0] += grade; 
			if(i == 1)
			{
				kq[1] = grade;
				kq[2] = grade;
			}
			if(grade > kq[1])
				kq[1] = grade;
			if(grade < kq[2])
				kq[2] = grade;
			i++;
		} while (i <= n);	
		return kq;
	}
}
