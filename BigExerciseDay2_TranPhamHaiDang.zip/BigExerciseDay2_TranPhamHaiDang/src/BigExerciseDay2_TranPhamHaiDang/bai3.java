package BigExerciseDay2_TranPhamHaiDang;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class bai3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhập số dòng:");
			int n = sc.nextInt();
			System.out.println("Nhập số cột:");
			int m = sc.nextInt();
			int[][] a = new int[n][m];
			Random random = new Random();
			for (int i = 0; i < a.length; i++)
				for(int j = 0; j < a[i].length; j++)
					a[i][j] = random.nextInt(101);
			System.out.println("Mảng ngẫu nhiên vừa tạo:");
			xuatMang(a);
			
			sapXepCotTangDan(a, n);
			System.out.println("Mảng sau khi được sắp xếp:");
			xuatMang(a);
			
			System.out.println("Tổng các phẩn tử thuộc dòng chẵn cột lẻ: " 
			+ tongPhanTuThuocDongChanCotLe(a));
			
			thayGiaTriSNT(a);
			System.out.println("Mảng sau khi gán giá trị -1 cho các số nguyên tố:");
			xuatMang(a);
			
			int[] kq = tongPhanTu_DongDauTien_DongCuoiCung_CotDauTien_CotCuoiCung(a, n, m);
			System.out.println("Tổng các phần tử của dòng đầu tiên, dòng cuối cùng, cột đầu tiên, cột cuối cùng lần lượt là: \n" 
			+ kq[0] + ", " + kq[1] + ", " + kq[2] + ", " + kq[3]);
			
			System.out.println("Vị trí các phân tử là số chính phương trong mảng:");
			inViTriCacSoChinhPhuongTrongMang(a);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}
	}
	public static void xuatMang(int[][] a) {
		for (int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
	}
	public static void sapXepCotTangDan(int[][] a, int n) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập một cột bất kì:");
		int cot = sc.nextInt();
		int[] temp = new int[n];
		for(int i = 0 ; i < n; i++)
			temp[i] = a[i][cot];
		Arrays.sort(temp);
		for(int i = 0 ; i < n; i++)
			a[i][cot] = temp[i];
	}
	public static int tongPhanTuThuocDongChanCotLe(int[][] a) {
		int dem = 0;
		for (int i = 0; i < a.length; i++)
		{
			if(i % 2 == 0)
			{
				for(int j = 0; j < a[i].length; j++)
					if(j % 2 != 0)
						dem++;
			}					
		}
		return dem;
	}
	public static boolean ktSNT(int n) {
		if(n < 2) return false;
		for(int i = 2; i <= Math.sqrt(n); i++)
			if(n % i == 0)
				return false;
		return true;
	}
	public static void thayGiaTriSNT(int[][] a) {
		for (int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
				if(ktSNT(a[i][j]) == true)
					a[i][j] = -1;
		}
	}
	public static int[] tongPhanTu_DongDauTien_DongCuoiCung_CotDauTien_CotCuoiCung(int[][] a, int n, int m) {
		int[] kq = new int[4];
		for (int i = 0; i < m; i++)
		{
			kq[0] += a[0][i];
			kq[1] += a[n-1][i];
		}
		for (int i = 0; i < n; i++)
		{
			kq[2] += a[i][0];
			kq[3] += a[i][m-1];
		}
		return kq;
	}
	public static boolean ktSoChinhPhuong(int n) {
		if(n == (int)Math.sqrt(n) * (int)Math.sqrt(n))
			return true;
		return false;
	}
	public static void inViTriCacSoChinhPhuongTrongMang(int[][] a) {
		for (int i = 0; i < a.length; i++)
		{
			for(int j = 0; j < a[i].length; j++)
				if(ktSoChinhPhuong(a[i][j]) == true)
					System.out.println("Dong " + i + " Cot " + j);
		}
	}
}
