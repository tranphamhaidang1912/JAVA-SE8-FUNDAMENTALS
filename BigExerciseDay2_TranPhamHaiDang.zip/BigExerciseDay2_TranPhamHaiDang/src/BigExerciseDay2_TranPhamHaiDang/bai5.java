package BigExerciseDay2_TranPhamHaiDang;

public class bai5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			veBanCo();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi: " + e.toString());
		}
	}
	public static void veBanCo() {
		for(int i = 1; i <= 8 ; i++)
		{
			System.out.println("-----------------------------------------------");
			if(i % 2 != 0)
				for(int j = 1 ; j <= 8 ; j++)
					if(j % 2 != 0)
						System.out.print("| W | ");
					else
						System.out.print("| B | ");
			else
				for(int j = 1 ; j <= 8 ; j++)
					if(j % 2 != 0)
						System.out.print("| B | ");
					else
						System.out.print("| W | ");
			System.out.println();
		}
		System.out.println("-----------------------------------------------");
	}
}
