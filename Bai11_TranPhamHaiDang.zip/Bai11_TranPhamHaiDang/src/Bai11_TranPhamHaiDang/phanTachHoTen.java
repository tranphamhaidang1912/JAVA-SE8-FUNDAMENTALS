package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachHoTen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap ho ten:");
			String hoTen = sc.nextLine();
			phanTachHoTen(hoTen);
		} catch (IllegalArgumentException e) {
			// TODO: handle exception
			System.err.println("Loi: " + e.toString());
		}
		
	}
	public static void phanTachHoTen(String hoTen) {
		StringTokenizer st = new StringTokenizer(hoTen);
		String ho = st.nextToken();
		String tenDem = "";
		while(st.countTokens() > 1)
			tenDem += st.nextToken() + " ";
		String ten = st.nextToken();
		System.out.println(ho);
		System.out.println(tenDem);
		System.out.println(ten);
	}
}
