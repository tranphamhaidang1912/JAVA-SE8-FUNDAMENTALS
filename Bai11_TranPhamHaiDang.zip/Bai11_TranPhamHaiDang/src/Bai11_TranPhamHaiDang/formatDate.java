package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class formatDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap ngay thang nam:");
		String date = sc.nextLine();
		Pattern p = Pattern.compile("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)[0-9][0-9])$");
		Matcher m = p.matcher(date);
		boolean b = m.matches();
		if(b == true)
			System.out.println("Ngay thang nam hop le");
		else
			System.out.println("Ngay thang nam khong hop le");
	}

}
