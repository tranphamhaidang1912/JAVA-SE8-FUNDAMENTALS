package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class formatTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap gio:");
		String time = sc.nextLine();
		Pattern p = Pattern.compile("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
		Matcher m = p.matcher(time);
		boolean b = m.matches();
		if(b == true)
			System.out.println("Gio hop le");
		else
			System.out.println("Gio khong hop le");
	}
}
