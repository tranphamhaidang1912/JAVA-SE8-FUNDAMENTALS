package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class formatImageFileName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap image file:");
		String imageFile = sc.nextLine();
		Pattern p = Pattern.compile("[^\\s]+(\\.(?i)(jpg|png|gif|bmp))$");
		Matcher m = p.matcher(imageFile);
		boolean b = m.matches();
		if(b == true)
			System.out.println("Image file hop le");
		else
			System.out.println("Image file khong hop le");
	}
}
