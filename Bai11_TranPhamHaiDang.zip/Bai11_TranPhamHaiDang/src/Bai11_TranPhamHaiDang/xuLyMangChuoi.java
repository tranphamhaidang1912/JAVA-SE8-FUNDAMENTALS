package Bai11_TranPhamHaiDang;

import java.util.Arrays;
import java.util.Scanner;

public class xuLyMangChuoi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n:");
		int n = sc.nextInt();
		sc.nextLine();
		String[] mangTen = new String[n];
		for(int i = 0; i < mangTen.length; i++)
			mangTen[i] = sc.nextLine();
		for(String value : mangTen)
			System.out.println(value);
		System.out.println("Nhap ten mot nguoi bat ki: ");
		String ten = sc.nextLine();
		int viTriXuatHienDauTien = -1;
		for(int i = 0; i < mangTen.length; i++)
		{
			if(mangTen[i].indexOf(ten) >= 0)
			{
				viTriXuatHienDauTien = i;
				break;
			}
		}
		if(viTriXuatHienDauTien != -1)
			System.out.println("Vi tri xuat hien dau tien cua ten vua nhap trong mang la: " + viTriXuatHienDauTien);
		else System.out.println("Khong co ten vua nhap trong mang");
		System.out.println("Nhung phan tu trong do co ky tu n trong mangTen:");
		int dem = 0;
		for(int i = 0; i < mangTen.length; i++)
		{
			if(mangTen[i].indexOf("n") >= 0)
			{
				System.out.println(mangTen[i]);
				dem++;
			}				
		}
		if(dem == 0)
			System.out.println("Khong co phan tu nao co ki tu \"n\" trong mangTen");
		System.out.println("Mang sau khi sap xep theo thu tu tang dan alphabet:");
		Arrays.sort(mangTen);
		for(String value : mangTen)
			System.out.println(value);
	}
}
