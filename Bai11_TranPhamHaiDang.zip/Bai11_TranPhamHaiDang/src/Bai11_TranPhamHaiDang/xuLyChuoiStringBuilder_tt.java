package Bai11_TranPhamHaiDang;

import java.util.Scanner;

public class xuLyChuoiStringBuilder_tt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap chuoi sb:");
		StringBuilder sb = new StringBuilder(sc.nextLine());
		for(int i = 0; i < sb.length(); i++)
			System.out.println(sb.charAt(i));
		System.out.println("Nhap chuoi kt:");
		StringBuilder kt = new StringBuilder(sc.nextLine());
		int viTriXuatHien = sb.indexOf(kt.toString());
		if(viTriXuatHien >= 0)
			System.out.println("Chuoi kt xuat hien trong chuoi sb tai vi tri: " + viTriXuatHien);
		else System.out.println("Chuoi kt khong xuat hien trong chuoi sb");
	}

}
