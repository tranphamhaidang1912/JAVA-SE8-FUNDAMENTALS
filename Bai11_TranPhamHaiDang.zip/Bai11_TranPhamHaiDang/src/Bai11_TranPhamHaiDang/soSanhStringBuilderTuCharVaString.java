package Bai11_TranPhamHaiDang;

public class soSanhStringBuilderTuCharVaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long t1 = System.currentTimeMillis();
		StringBuilder sb1 = new StringBuilder(10000);
		for(int i = 1; i <= 10000; i++)
			sb1.append('A');
		long t2 = System.currentTimeMillis();
		StringBuilder sb2 = new StringBuilder(10000);
		for(int i = 1; i <= 10000; i++)
			sb2.append('A');
		long t3 = System.currentTimeMillis();
		long tsb1 = t2 - t1;
		long tsb2 = t3 - t1;
		System.out.println("Chieu dai chuoi s: " + sb1.length());
		System.out.println("Chieu dai chuoi sb: " + sb2.length());
		System.out.println("Thoi gian thuc hien s: " + tsb1);
		System.out.println("Thoi gian thuc hien sb: " + tsb2);
		if(tsb1 > tsb2)
			System.out.println("Thoi gian sb1 dai hon sb2");
		else if(tsb1 < tsb2)
			System.out.println("Thoi gian sb1 nho hon sb2");
		else System.out.println("Thoi gian sb1 bang sb2");
	}

}
