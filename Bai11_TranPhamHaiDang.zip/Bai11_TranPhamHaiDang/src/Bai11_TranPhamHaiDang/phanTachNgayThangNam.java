package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachNgayThangNam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap chuoi ngay thang nam:");
			String s = sc.nextLine();
			phanTachNgayThangNam(s);
		} catch (IllegalArgumentException e) {
			// TODO: handle exception
			System.err.println("Loi: " + e.toString());
		}		
	}
	public static void phanTachNgayThangNam(String s) {
		StringTokenizer st = new StringTokenizer(s, "/");
		String ngay = st.nextToken();
		String thang = st.nextToken();
		String nam = st.nextToken();
		System.out.println(ngay);
		System.out.println(thang);
		System.out.println(nam);
	}
}
