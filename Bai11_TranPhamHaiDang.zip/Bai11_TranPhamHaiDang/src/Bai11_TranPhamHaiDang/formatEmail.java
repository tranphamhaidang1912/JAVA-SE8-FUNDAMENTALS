package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class formatEmail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap email:");
		String email = sc.nextLine();
		Pattern p = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher m = p.matcher(email);
		boolean b = m.matches();
		if(b == true)
			System.out.println("Email hop le");
		else
			System.out.println("Email khong hop le");
	}

}
