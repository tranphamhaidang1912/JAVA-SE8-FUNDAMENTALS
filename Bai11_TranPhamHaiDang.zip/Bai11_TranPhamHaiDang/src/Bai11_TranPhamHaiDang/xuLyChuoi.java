package Bai11_TranPhamHaiDang;

import java.util.Scanner;

public class xuLyChuoi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap chuoi s1:");
		String s1 = sc.nextLine();
		System.out.println("Nhap chuoi s2:");
		String s2 = sc.nextLine();
		System.out.println("Nhap chuoi s3:");
		String s3 = sc.nextLine();
		System.out.println("Nhap vi tri v:");
		int v = sc.nextInt();
		System.out.println("Chieu dai chuoi s1: " + s1.length());
		System.out.println("Chieu dai chuoi s2: " + s2.length());
		System.out.println("Chieu dai chuoi s3: " + s3.length());
		System.out.println("Ket qua so s1 & s2: " + s1.compareTo(s2));
		System.out.println("Vi tri xuat hien dau tien cua chuoi s3 trong s1: " + s1.indexOf(s3));
		System.out.println("Chuoi s4: " + s1.substring(v));
	}
}
