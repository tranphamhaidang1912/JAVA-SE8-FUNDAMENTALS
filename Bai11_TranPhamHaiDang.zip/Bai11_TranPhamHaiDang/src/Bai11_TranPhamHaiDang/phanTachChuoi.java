package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachChuoi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap chuoi can phan tach:");
			String chuoiCanPhanTach = sc.nextLine();
			System.out.println("Nhap ky tu phan tach");
			String kiTuPhanTach = sc.nextLine();
			phanTachChuoi(chuoiCanPhanTach, kiTuPhanTach);
		} catch (IllegalArgumentException e) {
			// TODO: handle exception
			System.err.println("Loi: " + e.toString());
		}
		
	}
	public static void phanTachChuoi(String chuoiCanPhanTach, String kiTuPhanTach) {
		StringTokenizer st = new StringTokenizer(chuoiCanPhanTach, kiTuPhanTach);
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());
	}
}
