package Bai11_TranPhamHaiDang;

import java.util.Scanner;

public class xuLyChuoiStringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap chuoi sb:");
		StringBuilder sb = new StringBuilder(sc.nextLine());
		System.out.println("Nhap chuoi sb1:");
		StringBuilder sb1 = new StringBuilder(sc.nextLine());
		System.out.println("Nhap chuoi sb2:");
		StringBuilder sb2 = new StringBuilder(sc.nextLine());
		System.out.println("Nhap chuoi sb3:");
		StringBuilder sb3 = new StringBuilder(sc.nextLine());
		System.out.println("Nhap chuoi sb4:");
		StringBuilder sb4 = new StringBuilder(sc.nextLine());
		System.out.println("Nhap vi tri chen:");
		int viTriChen = sc.nextInt();
		System.out.println("Nhap vi tri bat dau:");
		int viTriBatDau = sc.nextInt();
		System.out.println("Nhap vi tri cuoi:");
		int viTriCuoi = sc.nextInt();
		
		System.out.println("Chieu dai chuoi sb1: " + sb1.length());
		System.out.println("Chieu dai chuoi sb2: " + sb2.length());
		System.out.println("Chieu dai chuoi sb3: " + sb3.length());
		System.out.println("Chieu dai chuoi sb4: " + sb4.length());
		System.out.println("Chuoi sb sau khi noi chuoi sb1 vao: " + sb.append(sb1));
		System.out.println("Chuoi sb sau khi chen chuoi sb2 vao tai vi tri chen: " + sb.insert(viTriChen, sb2));
		System.out.println("Chuoi sb sau khi xoa noi dung tu vi tri dau den vi tri cuoi: " + sb.delete(viTriBatDau, viTriCuoi));
		System.out.println("Chuoi sb sau khi dao nguoc: " + sb.reverse());
	}
}
