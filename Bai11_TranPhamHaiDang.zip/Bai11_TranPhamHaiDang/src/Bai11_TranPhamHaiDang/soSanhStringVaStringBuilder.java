package Bai11_TranPhamHaiDang;

public class soSanhStringVaStringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long t1 = System.currentTimeMillis();
		String s = new String();		
		for(int i = 1; i <= 10000; i++)
			s = s.concat(i + " ");
		long t2 = System.currentTimeMillis();
		StringBuilder sb = new StringBuilder(10000);
		for(int i = 1; i <= 10000; i++)
			sb.append(i + " ");
		long t3 = System.currentTimeMillis();
		long ts = t2 - t1;
		long tsb = t3 - t1;
		System.out.println("Chieu dai chuoi s: " + s.length());
		System.out.println("Chieu dai chuoi sb: " + sb.length());
		System.out.println("Thoi gian thuc hien s: " + ts);
		System.out.println("Thoi gian thuc hien sb: " + tsb);
		if(ts > tsb)
			System.out.println("Thoi gian s dai hon sb");
		else if(ts < tsb)
			System.out.println("Thoi gian s nho hon sb");
		else System.out.println("Thoi gian s bang sb");
	}
}
