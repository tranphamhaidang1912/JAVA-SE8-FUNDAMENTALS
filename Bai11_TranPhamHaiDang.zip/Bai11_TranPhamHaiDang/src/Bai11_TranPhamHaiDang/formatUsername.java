package Bai11_TranPhamHaiDang;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class formatUsername {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap username:");
		String username = sc.nextLine();
		Pattern p = Pattern.compile("^[a-z0-9_-]{6,20}$");
		Matcher m = p.matcher(username);
		boolean b = m.matches();
		if(b == true)
			System.out.println("Username hop le");
		else
			System.out.println("Username khong hop le");
	}
}
