package Bai11_TranPhamHaiDang;

public class hienThiMaTranKieuChuoi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i = 1; i <= 8; i++)
		{
			for(int j = 1; j <= 8 ; j++)
			{
				if(i >= j)
					System.out.print("# ");
			}
			System.out.println();
		}
		System.out.println("     (a)\n");	
		for(int i = 1; i <= 8; i++)
		{
			for(int j = 1; j <= 8 ; j++)
			{
				if(i <= j)
					System.out.print("# ");
			}
			System.out.println();
		}
		System.out.println("     (b)\n");
		StringBuilder s1 = new StringBuilder();
		for(int i = 1; i <= 8; i++)
		{
			for(int j = 1; j <= 8 ; j++)
			{
				if(i > j) 
					System.out.print("  ");
				else
					System.out.print("# ");
			}
			System.out.println();
		}
		System.out.println("     (c)\n");
		for(int i = 1; i <= 8; i++)
		{
			for(int j = 1; j <= 8 ; j++)
			{
				if(i + j <= 8) 
					System.out.print("  ");
				else
					System.out.print("# ");
			}
			System.out.println();
		}
		System.out.println("     (d)\n");
		for(int i = 1; i <= 7; i++)
		{
			for(int j = 1; j <= 7 ; j++)
			{
				if(i == 1 || i == 7 || j == 1 || j == 7)
					System.out.print("# ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
		System.out.println("     (e)\n");
		for(int i = 1; i <= 7; i++)
		{
			for(int j = 1; j <= 7 ; j++)
			{
				if(i == 1 || i == 7 || i == j)
					System.out.print("# ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
		System.out.println("     (f)\n");
		for(int i = 1; i <= 7; i++)
		{
			for(int j = 1; j <= 7 ; j++)
			{
				if(i == 1 || i == 7 || i + j == 8)
					System.out.print("# ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
		System.out.println("     (g)\n");
		for(int i = 1; i <= 7; i++)
		{
			for(int j = 1; j <= 7 ; j++)
			{
				if(i == 1 || i == 7 || i == j || i + j == 8)
					System.out.print("# ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
		System.out.println("     (h)\n");
		for(int i = 1; i <= 7; i++)
		{
			for(int j = 1; j <= 7 ; j++)
			{
				if(i == 1 || i == 7 || j == 1 || j == 7 || i == j || i + j == 8)
					System.out.print("# ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
		System.out.println("     (i)\n");
	}
}
