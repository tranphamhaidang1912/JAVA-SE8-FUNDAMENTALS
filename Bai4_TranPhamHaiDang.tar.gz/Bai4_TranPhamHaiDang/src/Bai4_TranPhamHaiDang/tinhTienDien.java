package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhTienDien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap so kw tieu thu:");
		int soKWH = sc.nextInt();
		final double bac1 = 1388;
		final double bac2 = 1433;
		final double bac3 = 1660;
		final double bac4 = 2082;
		final double bac5 = 2324;
		final double bac6 = 2399;
		double thanhTien;
		if(soKWH <= 50) thanhTien = bac1 * soKWH;
		else if(soKWH <= 100) thanhTien = bac2 * (soKWH - 50) + bac1 * 50;
		else if(soKWH <= 200) thanhTien = (bac1 + bac2) * 50 + bac3 * (soKWH - 100);
		else if(soKWH <= 300) thanhTien = (bac1 + bac2) * 50 + bac3 * 100 + bac4 * (soKWH - 200);
		else if(soKWH <= 400) thanhTien = (bac1 + bac2) * 50 + (bac3 + bac4) * 100 + bac5 * (soKWH - 300);
		else thanhTien = (bac1 + bac2) * 50 + (bac3 + bac4 + bac5) * 100 + bac6 * (soKWH - 400);
		System.out.println("Thanh tien = " + thanhTien);
	}

}
