package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhCuocTaxi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap loai xe (4 hoac 7):");
		int loaiXe = sc.nextInt();
		System.out.println("Nhap so km:");
		double soKM = sc.nextDouble();
		double thanhTien;
		if(loaiXe == 4)
		{
			if(soKM <= 0.8) thanhTien = 11000;
			else if(soKM <=30) thanhTien = (soKM - 0.8) * 16500 + 11000;
			else thanhTien = (soKM - 30.8) * 12400 + (30 - 0.8) * 16500 + 11000;
		}
		else
		{
			if(soKM <= 0.8) thanhTien = 11000;
			else if(soKM <=30) thanhTien = (soKM - 0.8) * 17000 + 11000;
			else thanhTien = (soKM - 30.8) * 14400 + (30 - 0.8) * 17000 + 11000;
		}
		System.out.println("Thanh tien = " + thanhTien);
	}

}
