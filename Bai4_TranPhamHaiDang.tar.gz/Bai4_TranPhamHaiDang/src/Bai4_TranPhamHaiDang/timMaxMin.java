package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class timMaxMin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap a:");
		int a =sc.nextInt();
		System.out.println("Nhap b:");
		int b =sc.nextInt();
		System.out.println("Nhap c:");
		int c =sc.nextInt();
		System.out.println("Nhap d:");
		int d =sc.nextInt();
		int max = Math.max(a, b);
		int min = Math.min(a, b);
		if(Math.max(a, b) < Math.max(c, d)) max = Math.max(c, d);
		if(Math.min(a, b) > Math.min(c, d)) min = Math.min(c, d);
		System.out.println("So lon nhat: " + max);
		System.out.println("So be nhat: " + min);
	}

}
