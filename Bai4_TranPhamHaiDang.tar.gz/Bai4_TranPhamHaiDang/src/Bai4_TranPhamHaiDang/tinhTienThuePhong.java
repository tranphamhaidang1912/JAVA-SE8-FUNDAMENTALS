package Bai4_TranPhamHaiDang;

import java.util.Scanner;

public class tinhTienThuePhong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap loai phong:");
		int loaiPhong = sc.nextInt();
		System.out.println("Nhap so dem:");
		int soDem = sc.nextInt();
		final double loai1 = 1260000;
		final double loai2 = 1550000;
		final double loai3 = 1830000;
		final double loai4 = 1830000;
		final double loai5 = 2120000;
		final double loai6 = 2120000;
		final double loai7 = 2540000;
		final double loai8 = 4800000;
		double thanhTien = 0;
		switch (loaiPhong) {
		case 1:
			thanhTien = tinhTienPhong(loai1, soDem);
			break;
		case 2:
			thanhTien = tinhTienPhong(loai2, soDem);
			break;
		case 3:
			thanhTien = tinhTienPhong(loai3, soDem);
			break;
		case 4:
			thanhTien = tinhTienPhong(loai4, soDem);
			break;
		case 5:
			thanhTien = tinhTienPhong(loai5, soDem);
			break;
		case 6:
			thanhTien = tinhTienPhong(loai6, soDem);
			break;
		case 7:
			thanhTien = tinhTienPhong(loai7, soDem);
			break;
		case 8:
			thanhTien = tinhTienPhong(loai8, soDem);
			break;
		default:
			break;
		}
		System.out.println("Thanh tien = " + thanhTien);
	}
	public static double tinhTienPhong(double gialoaiPhong, int soDem) {
		// TODO Auto-generated method stub
		if(soDem == 1) return gialoaiPhong;
		else if(soDem <= 3) return ((gialoaiPhong * 0.75) * soDem);
		else return ((gialoaiPhong * 0.7) * soDem);
	}
}
